import asyncio

import pytest

from pydantic import BaseModel

from src.deepeval import juiz

class Resultado(BaseModel):
    valor: int

def test_schema_e_temperatura_preservados(monkeypatch):
    chamadas = []

    class Cliente:

        def __init__(self, **kwargs):
            pass

        def chat(self, **kwargs):
            chamadas.append(kwargs)
            return {'message': {'content': '{"valor": 3}'}}
    monkeypatch.setattr(juiz.ollama, 'Client', Cliente)
    modelo = juiz.LocalOllamaModel()
    assert modelo.generate('prompt', Resultado).valor == 3
    assert asyncio.run(modelo.a_generate('prompt', Resultado)).valor == 3
    assert all((c['options']['temperature'] == 0.2 for c in chamadas))
    assert chamadas[0]['format'] == Resultado.model_json_schema()

def test_json_invalido_nao_recebe_nota(monkeypatch):
    chamadas = []

    class Cliente:

        def __init__(self, **kwargs):
            pass

        def chat(self, **kwargs):
            chamadas.append(kwargs)
            return {'message': {'content': '{"valor": "inválido"}'}}
    monkeypatch.setattr(juiz.ollama, 'Client', Cliente)
    with pytest.raises(ValueError):
        juiz.LocalOllamaModel().generate('prompt', Resultado)
    assert len(chamadas) == 1

def test_thresholds_preservados():
    assert [m.threshold for m in juiz.obter_metricas_base()] == [0.7, 0.8, 0.8]

def test_resposta_vazia_registra_diagnostico_sem_nota_ou_repeticao(monkeypatch):
    chamadas = []

    class Cliente:

        def __init__(self, **kwargs):
            pass

        def chat(self, **kwargs):
            chamadas.append(kwargs)
            return {'message': {'content': ''}, 'done_reason': 'length', 'eval_count': 4096}
    monkeypatch.setattr(juiz.ollama, 'Client', Cliente)
    modelo = juiz.LocalOllamaModel()
    with pytest.raises(ValueError, match='conteúdo vazio.*done_reason=length; eval_count=4096'):
        modelo.generate('prompt', Resultado)
    assert len(chamadas) == 1
    assert modelo.transport_retries == 0

def test_fonte_integral_preserva_dias_e_negacoes():
    from src.deepeval.fidelidade import FidelidadeFonteIntegral
    fonte = ['Terças: entrada gratuita das 10h às 20h. Sextas: gratuita apenas após as 18h.', 'Não há almoço gratuito informado.']
    metrica = FidelidadeFonteIntegral(model=juiz.LocalOllamaModel())
    assert metrica._generate_truths(fonte) == fonte
    assert asyncio.run(metrica._a_generate_truths(fonte)) == fonte
    with pytest.raises(ValueError):
        metrica._generate_truths([])

def test_extracao_nao_altera_ano_ou_negacao():
    from src.deepeval.extracao import trechos_literais
    resposta = 'A obra é de 2009. Não existe espada na descrição.'
    assert trechos_literais([resposta]) == ['A obra é de 2009.', 'Não existe espada na descrição.']
    with pytest.raises(ValueError):
        trechos_literais('')

def test_repeticao_limitada_a_falha_transitoria(monkeypatch):
    chamadas = []

    class Cliente:

        def __init__(self, **kwargs):
            pass

        def chat(self, **kwargs):
            chamadas.append(kwargs)
            if len(chamadas) == 1:
                raise juiz.httpx.ReadTimeout('falha de transporte de teste')
            return {'message': {'content': '{"valor": 3}'}}
    monkeypatch.setattr(juiz.ollama, 'Client', Cliente)
    monkeypatch.setattr(juiz.time, 'sleep', lambda _: None)
    modelo = juiz.LocalOllamaModel()
    assert modelo.generate('prompt', Resultado).valor == 3
    assert len(chamadas) == 2 and modelo.transport_retries == 1
    assert chamadas[0] == chamadas[1]

def test_erro_permanente_nao_e_repetido(monkeypatch):
    chamadas = []

    class Cliente:

        def __init__(self, **kwargs):
            pass

        def chat(self, **kwargs):
            chamadas.append(kwargs)
            raise juiz.ollama.ResponseError('modelo ausente', status_code=404)
    monkeypatch.setattr(juiz.ollama, 'Client', Cliente)
    with pytest.raises(juiz.ollama.ResponseError):
        juiz.LocalOllamaModel().generate('prompt', Resultado)
    assert len(chamadas) == 1


from src.deepeval.casos import montar_casos

def test_conformidade_recebe_ambos_turnos_sem_ocultar_erro_anterior():
    perguntas = ['Quem criou a obra?', 'E a técnica?']
    respostas = ['A autora é Nome Errado.', 'A técnica é aquarela.']
    esperado = 'T1: Ana Teste. T2: aquarela.'
    ultima, conversa = montar_casos(perguntas, respostas, esperado, ['Autora: Ana Teste. Técnica: aquarela.'])
    assert ultima.actual_output == respostas[1]
    assert respostas[0] in ultima.input
    assert all((r in conversa.actual_output for r in respostas))
    assert all((p in conversa.input for p in perguntas))
    assert esperado not in conversa.input and esperado not in conversa.actual_output
    assert conversa.expected_output == esperado
    assert conversa.retrieval_context == ultima.retrieval_context

def test_consulta_unica_preserva_resposta_literal():
    ultima, conversa = montar_casos(['Técnica?'], ['Aquarela.'], 'Informar técnica.', ['Aquarela.'])
    assert ultima is conversa and ultima.actual_output == 'Aquarela.'

def test_conversa_incompleta_nao_e_silenciosamente_truncada():
    with pytest.raises(ValueError):
        montar_casos(['T1', 'T2'], ['R1'], 'Critério', ['Fonte'])
    with pytest.raises(ValueError):
        montar_casos([], [], 'Critério', ['Fonte'])





def test_separar_turnos_legados():
    from src.deepeval.dataset import separar_turnos
    assert separar_turnos('T1: "Fale sobre a obra." / T2: "E o contexto?"') == ['Fale sobre a obra.', 'E o contexto?']
    assert separar_turnos('"O museu abre?"') == ['O museu abre?']

def test_dataset_preserva_35_casos():
    import json
    from pathlib import Path
    from src.deepeval.dataset import separar_turnos
    casos = json.loads((Path(__file__).parents[1] / 'dados/golden_dataset.json').read_text(encoding='utf-8'))
    assert len(casos) == 35 and len({c['id'] for c in casos}) == 35
    for caso in casos:
        assert len(separar_turnos(caso['input'])) == (2 if caso['categoria'] == 'Multi-turno' else 1)

def test_entrada_invalida_do_dataset_e_rejeitada():
    from src.deepeval.dataset import separar_turnos
    for entrada in (None, '', '   ', 42):
        with pytest.raises(ValueError, match='texto não vazio'):
            separar_turnos(entrada)


def test_golden_cobre_cinco_categorias_com_sete_casos():
    import json
    from collections import Counter
    from pathlib import Path
    casos = json.loads((Path(__file__).parents[1] / 'dados/golden_dataset.json').read_text(encoding='utf-8'))
    contagem = Counter(caso['categoria'] for caso in casos)
    assert len(contagem) == 5 and set(contagem.values()) == {7}
