# Estudo: nomes claros, responsabilidades explícitas e comentários sobre decisões.
# Os testes fixam comportamentos observáveis e usam dublês nas fronteiras.
# Isso verifica código; a qualidade do golden continua dependendo dos modelos reais.

import sys
from pathlib import Path
raiz = str(Path(__file__).resolve().parents[1])
if raiz not in sys.path:
    sys.path.insert(0, raiz)
