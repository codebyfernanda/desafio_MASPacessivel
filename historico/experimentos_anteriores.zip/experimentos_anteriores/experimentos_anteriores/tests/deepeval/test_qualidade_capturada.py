"""Avalia uma captura completa congelada, com o mesmo juiz e sem seleção por nota."""
import hashlib
import json
import os
import time
from pathlib import Path
import pytest
from src.deepeval.casos import montar_casos
from src.deepeval.juiz import obter_metricas_base, JUIZ_PADRAO

RAIZ = Path(__file__).resolve().parents[2]
GOLDEN = json.loads((RAIZ / 'dados/golden_dataset.json').read_text(encoding='utf-8'))


@pytest.fixture(scope='session')
def rodada():
    origem = Path(os.environ['MASP_CAPTURA_QUALIDADE'])
    saida = Path(os.environ['MASP_RESULTADO_QUALIDADE'])
    if saida.exists():
        pytest.fail('O resultado já existe. Preserve-o e escolha outro destino para uma nova rodada.')
    captura = json.loads(origem.read_text(encoding='utf-8'))
    assert captura['metadata']['status'] == 'finalizado'
    assert [r['id'] for r in captura['resultados']] == [c['id'] for c in GOLDEN]
    sha_golden = hashlib.sha256((RAIZ / 'dados/golden_dataset.json').read_bytes()).hexdigest()
    assert captura['metadata']['dataset_sha256'] == sha_golden
    dados = {'metadata': {
        'status': 'em_execucao', 'captura': str(origem),
        'captura_sha256': hashlib.sha256(origem.read_bytes()).hexdigest(),
        'dataset_sha256': sha_golden, 'thresholds': [.7, .8, .8], 'temperatura_juiz': .2,
        'modelos': {k: os.getenv(k, JUIZ_PADRAO) for k in ('MASP_JUDGE_MODEL', 'MASP_FAITHFULNESS_MODEL', 'MASP_CONFORMITY_MODEL')},
        'avaliador_sha256': {str(p.relative_to(RAIZ)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((RAIZ / 'src/deepeval').glob('*.py'))},
        'protocolo': '35 casos; captura imutável; juiz, templates, temperaturas e thresholds preservados; sem repetição por nota.'
    }, 'resultados': []}
    inicio = time.monotonic()

    def salvar(etapa=None):
        if etapa:
            dados['metadata']['etapa_atual'] = etapa
        dados['metadata']['duracao_segundos'] = round(time.monotonic() - inicio, 2)
        temporario = saida.with_suffix('.tmp')
        temporario.write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding='utf-8')
        temporario.replace(saida)

    salvar()
    yield captura, dados, salvar
    dados['metadata']['status'] = 'finalizado' if len(dados['resultados']) == len(GOLDEN) else 'interrompido'
    dados['metadata'].pop('etapa_atual', None)
    salvar()


@pytest.mark.parametrize('caso', GOLDEN, ids=lambda c: c['id'])
def test_qualidade_capturada(rodada, caso):
    captura, dados, salvar = rodada
    registro = next(r for r in captura['resultados'] if r['id'] == caso['id'])
    resultado = {'versao': 'candidata_v4', 'caso_id': caso['id'], 'categoria': caso['categoria'], 'metricas': [], 'sucesso': False}
    try:
        assert not registro.get('erro'), registro.get('erro')
        if 'ferramenta' in caso['categoria'].lower():
            assert registro['tool_calls'] and any('**Obra ' in d for t in registro['tool_calls'] for d in t['documents'])
        contexto = list(dict.fromkeys(d for t in registro['tool_calls'] for d in t['documents'])) + [registro['system_prompt']]
        ultima, conversa = montar_casos(registro['turnos'], registro['respostas'], caso['expected_output'], contexto)
        for metrica, evidencia in zip(obter_metricas_base(), (ultima, ultima, conversa), strict=True):
            item = {'nome': metrica.name, 'threshold': metrica.threshold, 'modelo': metrica.model.get_model_name(), 'passou': False,
                    'input_avaliado': evidencia.input, 'resposta_avaliada': evidencia.actual_output}
            salvar({'caso': caso['id'], 'metrica': metrica.name})
            try:
                metrica.measure(evidencia)
                item.update(score=metrica.score, passou=bool(metrica.is_successful()), razao=metrica.reason)
                for campo in ('statements', 'claims', 'verdicts'):
                    valores = getattr(metrica, campo, None)
                    if valores is not None:
                        item[campo] = [v.model_dump() if hasattr(v, 'model_dump') else v for v in valores]
            except Exception as erro:
                item.update(score=None, erro=f'{type(erro).__name__}: {erro}')
            item['repeticoes_transporte'] = getattr(metrica.model, 'transport_retries', 0)
            resultado['metricas'].append(item)
        resultado['sucesso'] = len(resultado['metricas']) == 3 and all(m['passou'] for m in resultado['metricas'])
    except Exception as erro:
        resultado['erro'] = f'{type(erro).__name__}: {erro}'
    dados['resultados'].append(resultado)
    salvar()
    assert resultado['sucesso'], json.dumps(resultado, ensure_ascii=False)
