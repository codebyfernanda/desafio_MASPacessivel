# Estudo: nomes claros, responsabilidades explícitas e comentários sobre decisões.
# Os testes fixam comportamentos observáveis e usam dublês nas fronteiras.
# Isso verifica código; a qualidade do golden continua dependendo dos modelos reais.

"""Avaliação real com relatórios incrementais; erros nunca contam como aprovação."""
import hashlib
import json
import os
import time
from datetime import datetime
from pathlib import Path
os.environ.setdefault('DEEPEVAL_TELEMETRY_OPT_OUT', 'YES')
import pytest
from src.agente.chatbot import MASPChatbot
from src.deepeval.dataset import separar_turnos
from src.deepeval.casos import montar_casos
from src.deepeval.juiz import obter_metricas_base, JUIZ_PADRAO
RAIZ = Path(__file__).resolve().parents[2]
DATASET = RAIZ / 'dados/golden_dataset.json'
CASOS = json.loads(DATASET.read_text(encoding='utf-8'))

@pytest.fixture(scope='session')
def relatorio(request):
    selecionados = [i.callspec.params['caso']['id'] for i in request.session.items if hasattr(i, 'callspec') and 'caso' in i.callspec.params]
    inicio = time.monotonic()
    pasta = RAIZ / 'resultados/frente_b/execucoes'
    pasta.mkdir(parents=True, exist_ok=True)
    caminho_arquivo = pasta / f'deepeval_log_{datetime.now():%Y%m%d_%H%M%S_%f}.json'
    dados = {'metadata': {'status': 'em_execucao', 'casos_selecionados': selecionados, 'modelo_agente': os.getenv('MASP_MODEL', 'qwen2.5:7b'), 'modelo_juiz': os.getenv('MASP_JUDGE_MODEL', JUIZ_PADRAO), 'modelo_juiz_conformidade': os.getenv('MASP_CONFORMITY_MODEL', JUIZ_PADRAO), 'modelo_juiz_fidelidade': os.getenv('MASP_FAITHFULNESS_MODEL', JUIZ_PADRAO), 'temperatura_juiz': 0.2, 'temperatura_agente': 'padrão do Ollama, sem sobrescrita', 'thresholds': [0.7, 0.8, 0.8], 'execucao_metricas': 'síncrona e sequencial', 'timeout_juiz_segundos': 300, 'max_repeticoes_transporte': 1, 'templates': 'RelevanciaPT / FidelidadePT; G-Eval com etapas fixas', 'unidades_avaliadas': {'relevancia_fidelidade': 'última resposta', 'conformidade': 'respostas de todos os turnos'}, 'sha256': {str(f.relative_to(RAIZ)): hashlib.sha256(f.read_bytes()).hexdigest() for f in [DATASET, Path(__file__).resolve(), RAIZ / 'pytest.ini', RAIZ / 'requirements.txt', RAIZ / 'dados/base_conhecimento_rag.md', RAIZ / 'src/agente/prompt_de_sistema_inicial.md', *sorted((RAIZ / 'src').rglob('*.py'))]}}, 'resultados': []}

    def salvar(resultado=None, etapa=None):
        if etapa is not None:
            dados['metadata']['etapa_atual'] = etapa
        if resultado is not None:
            dados['resultados'].append(resultado)
        dados['metadata'].update(duracao_segundos=round(time.monotonic() - inicio, 2), total_casos=len(dados['resultados']), aprovados=sum((r['sucesso'] for r in dados['resultados'])))
        temporario = caminho_arquivo.with_suffix('.tmp')
        temporario.write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding='utf-8')
        temporario.replace(caminho_arquivo)
    salvar()
    yield salvar
    dados['metadata']['status'] = 'finalizado' if len(dados['resultados']) == len(selecionados) else 'interrompido'
    dados['metadata'].pop('etapa_atual', None)
    salvar()
    print(f'\nRelatório: {caminho_arquivo}')

@pytest.mark.parametrize('caso', CASOS, ids=lambda c: f"caso_{c['id']}")
def test_chatbot_baseline(caso, relatorio):
    resultado = {'caso_id': caso['id'], 'categoria': caso['categoria'], 'input': caso['input'], 'expected_output': caso['expected_output'], 'sucesso': False, 'metricas': [], 'respostas': []}
    try:
        guia_masp = MASPChatbot()
        turnos = separar_turnos(caso['input'])
        resultado['turnos'] = turnos
        for turno in turnos:
            resultado['respostas'].append(guia_masp.get_response(turno))
        contexto = list(dict.fromkeys((documento_consultado for t in guia_masp.tool_calls for documento_consultado in t['documents'])))
        contexto.append(guia_masp.system_prompt)
        resultado.update(retrieval_context=contexto, tool_calls=guia_masp.tool_calls, modos_resposta=guia_masp.response_origins)
        if 'ferramenta' in caso['categoria'].lower():
            assert guia_masp.tool_calls and any(('**Obra ' in d for d in contexto)), 'Busca de obra não realizada'
        teste, conversa = montar_casos(turnos, resultado['respostas'], caso['expected_output'], contexto)
        resultado['input_avaliado'] = teste.input
        metricas = obter_metricas_base()
        assert len(metricas) == 3, 'As três métricas são obrigatórias'
        for metrica, evidencia in zip(metricas, (teste, teste, conversa), strict=True):
            detalhe = {'nome_metrica': getattr(metrica, 'name', type(metrica).__name__), 'threshold': metrica.threshold, 'modelo': metrica.model.get_model_name(), 'passou': False, 'input_avaliado': evidencia.input, 'resposta_avaliada': evidencia.actual_output}
            relatorio(etapa={'caso_id': caso['id'], 'metrica': detalhe['nome_metrica']})
            try:
                metrica.measure(evidencia)
                for campo in ('statements', 'truths', 'claims', 'verdicts'):
                    valores = getattr(metrica, campo, None)
                    if valores is not None:
                        detalhe[campo] = [v.model_dump() if hasattr(v, 'model_dump') else v for v in valores]
                detalhe.update(score=metrica.score, razao=metrica.reason or 'Justificativas individuais registradas em verdicts.', passou=bool(metrica.is_successful()))
            except Exception as erro:
                detalhe.update(score=None, erro=f'{type(erro).__name__}: {erro}')
            detalhe['repeticoes_transporte'] = getattr(metrica.model, 'transport_retries', 0)
            resultado['metricas'].append(detalhe)
        resultado['sucesso'] = all((m['passou'] for m in resultado['metricas']))
    except Exception as erro:
        resultado['erro_execucao'] = f'{type(erro).__name__}: {erro}'
    finally:
        relatorio(resultado)
    assert resultado['sucesso'], json.dumps(resultado.get('erro_execucao') or resultado['metricas'], ensure_ascii=False)
