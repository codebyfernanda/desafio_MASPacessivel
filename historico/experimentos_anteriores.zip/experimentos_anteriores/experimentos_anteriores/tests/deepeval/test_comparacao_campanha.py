# Estudo: nomes claros, responsabilidades explícitas e comentários sobre decisões.
# As respostas congeladas permitem comparar as versões com o mesmo juiz.
# Nenhum resultado baixo é repetido apenas para buscar uma aprovação.

"""DeepEval real sobre capturas imutáveis das versões baseline e final (35 + 35)."""
import hashlib, json, os, time
from pathlib import Path
import pytest
from src.deepeval.casos import montar_casos
from src.deepeval.juiz import obter_metricas_base, JUIZ_PADRAO
RAIZ_PROJETO = Path(__file__).resolve().parents[2]
PASTA = RAIZ_PROJETO / 'resultados/frente_b/campanha_seguranca'
CASOS_REFERENCIA = json.loads((RAIZ_PROJETO / 'dados/golden_dataset.json').read_text(encoding='utf-8'))

@pytest.fixture(scope='session')
def comparacao():
    caminho_arquivo = Path(os.environ.get('MASP_COMPARACAO_SAIDA', str(PASTA / 'deepeval_comparacao.json')))
    if caminho_arquivo.exists():
        pytest.fail('Saída já existe. Preserve-a e use MASP_COMPARACAO_SAIDA para um novo ensaio.')
    capturas = {v: json.loads((PASTA / f'golden_{v}_respostas.json').read_text(encoding='utf-8')) for v in ('baseline', 'final')}
    sha = hashlib.sha256((RAIZ_PROJETO / 'dados/golden_dataset.json').read_bytes()).hexdigest()
    for cap in capturas.values():
        assert cap['metadata']['status'] == 'finalizado'
        assert cap['metadata']['dataset_sha256'] == sha
        assert [r['id'] for r in cap['resultados']] == [c['id'] for c in CASOS_REFERENCIA]
    modelos = {k: os.getenv(k, JUIZ_PADRAO) for k in ('MASP_JUDGE_MODEL', 'MASP_FAITHFULNESS_MODEL', 'MASP_CONFORMITY_MODEL')}
    dados = {'metadata': {'status': 'em_execucao', 'protocolo': '35 casos em cada versão; capturas reais imutáveis; mesma configuração do juiz; sem seleção por nota', 'modelos': modelos, 'thresholds': [0.7, 0.8, 0.8], 'temperatura_juiz': 0.2, 'dataset_sha256': sha, 'capturas_sha256': {v: hashlib.sha256((PASTA / f'golden_{v}_respostas.json').read_bytes()).hexdigest() for v in capturas}, 'avaliador_sha256': {str(p.relative_to(RAIZ_PROJETO)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((RAIZ_PROJETO / 'src/deepeval').glob('*.py'))}}, 'resultados': []}
    inicio = time.monotonic()

    def salvar(etapa=None):
        if etapa:
            dados['metadata']['etapa_atual'] = etapa
        dados['metadata']['duracao_segundos'] = round(time.monotonic() - inicio, 2)
        arquivo_temporario = caminho_arquivo.with_suffix('.tmp')
        arquivo_temporario.write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding='utf-8')
        arquivo_temporario.replace(caminho_arquivo)
    salvar()
    yield (capturas, dados, salvar)
    dados['metadata']['status'] = 'finalizado' if len(dados['resultados']) == 70 else 'interrompido'
    dados['metadata'].pop('etapa_atual', None)
    salvar()

@pytest.mark.parametrize('caso', CASOS_REFERENCIA, ids=lambda c: c['id'])
@pytest.mark.parametrize('versao', ['baseline', 'final'])
def test_metricas_capturadas(comparacao, caso, versao):
    capturas, dados, salvar = comparacao
    registro = next((r for r in capturas[versao]['resultados'] if r['id'] == caso['id']))
    resultado = {'versao': versao, 'caso_id': caso['id'], 'categoria': caso['categoria'], 'metricas': [], 'sucesso': False}
    try:
        assert not registro.get('erro'), registro.get('erro')
        if 'ferramenta' in caso['categoria'].lower():
            assert registro['tool_calls'] and any(('**Obra ' in d for t in registro['tool_calls'] for d in t['documents']))
        contexto = list(dict.fromkeys((d for t in registro['tool_calls'] for d in t['documents']))) + [registro['system_prompt']]
        ultima, conversa = montar_casos(registro['turnos'], registro['respostas'], caso['expected_output'], contexto)
        for metrica, evidencia in zip(obter_metricas_base(), (ultima, ultima, conversa), strict=True):
            item = {'nome': metrica.name, 'threshold': metrica.threshold, 'modelo': metrica.model.get_model_name(), 'passou': False, 'input_avaliado': evidencia.input, 'resposta_avaliada': evidencia.actual_output}
            salvar({'versao': versao, 'caso': caso['id'], 'metrica': metrica.name})
            try:
                metrica.measure(evidencia)
                item.update(score=metrica.score, passou=bool(metrica.is_successful()), razao=metrica.reason)
                for campo in ('statements', 'claims', 'verdicts'):
                    valores = getattr(metrica, campo, None)
                    if valores is not None:
                        item[campo] = [v.model_dump() if hasattr(v, 'model_dump') else v for v in valores]
            except Exception as erro_execucao:
                item.update(score=None, erro=f'{type(erro_execucao).__name__}: {erro_execucao}')
            item['repeticoes_transporte'] = getattr(metrica.model, 'transport_retries', 0)
            resultado['metricas'].append(item)
        resultado['sucesso'] = len(resultado['metricas']) == 3 and all((m['passou'] for m in resultado['metricas']))
    except Exception as erro_execucao:
        resultado['erro'] = f'{type(erro_execucao).__name__}: {erro_execucao}'
    dados['resultados'].append(resultado)
    salvar()
    assert resultado['sucesso'], json.dumps(resultado, ensure_ascii=False)
