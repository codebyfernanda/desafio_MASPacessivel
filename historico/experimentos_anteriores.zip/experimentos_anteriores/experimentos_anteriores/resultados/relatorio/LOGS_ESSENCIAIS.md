# Testes e logs essenciais

**Gemma nas duas frentes:** golden DeepEval baseline e final concluídos. Veja [comparação](../frente_b/gemma/comparacao_golden.json), [baseline](../frente_b/gemma/baseline.json) e [final](../frente_b/gemma/final.json). AR: 27/35 → 17/35; G-Eval: 9/35 → 18/35; Faithfulness: não avaliável → 32/35. Qwen é extra. Os 15 ataques também foram avaliados: [baseline](../frente_b/gemma/redteam_baseline.json), [final](../frente_b/gemma/redteam_final.json) e [comparação](../frente_b/gemma/comparacao_redteam.json). AR 6/15 → 6/15; G-Eval 5/15 → 8/15; Faithfulness não avaliável → 15/15; zero erros técnicos. Reprovação em métrica não é contagem de vulnerabilidades.

Numeração atual: **RT01 a RT15**. O [mapa de IDs](../../dados/redteam/mapa_ids.json) liga cada caso ao `id_original` dos logs já executados. Os IDs deste documento são atuais, salvo quando indicados como históricos. Perguntas, marcadores e evidências brutas permanecem iguais.


## 1. Suíte atual: 45 testes de código

Execute `python executar.py testes` no ambiente preparado, a partir da raiz. Também é possível executar um grupo com `python -m pytest tests/test_agentcore.py -q`, trocando o nome pelo grupo desejado.

| Grupo | Total | Cobertura principal |
|---|---:|---|
| [AgentCore](../../tests/test_agentcore.py) | 15 | Captura final, truncamento, falhas do runtime, versão do endpoint, parâmetros, sessões e regras da Lambda |
| [DeepEval](../../tests/test_deepeval.py) | 15 | Temperatura, thresholds, JSON inválido, respostas vazias, falhas de transporte, fontes, múltiplos turnos e golden completo |
| [Integração](../../tests/test_integracao.py) | 15 | Agente + RAG + proteções + memória + cliente simulado; fonte adulterada, PCD, horários, comparação, roupas e ausência de referência |

Resultado desta edição: **15/15 + 15/15 + 15/15 = 45/45 aprovados**. Veja o [XML atual](../frente_b/entrega_final/testes.xml), o [catálogo dos 45 nomes](../frente_b/revisao_45/catalogo_testes.json) e a [verificação de integridade](../frente_b/entrega_final/verificacao.json).

São testes simulados: **15 testes AgentCore aprovados não significam 15 avaliações executadas na AWS**. O golden com modelos reais continua com 35 casos. O recorte de red teaming possui 15 ataques, Os cinco controles benignos históricos são apoio e não entram no comando atual de ataque.

Foram reaproveitados 38 testes anteriores e acrescentadas sete verificações: erro de runtime, divergência de versão, filtro de span, contrato inválido, código fora do domínio, entrada inválida do dataset e equilíbrio das cinco categorias do golden. As asserções anteriores não foram afrouxadas.

## 2. Evidências de avaliação com modelos reais

Leia os resumos e abra os logs quando precisar conferir uma afirmação. Os registros completos mantêm aprovações, reprovações e erros.

| Evidência | Resultado e arquivos |
|---|---|
| Golden baseline × final local | **28/35 → 21/35**: [notas](../frente_b/campanha_seguranca/deepeval_comparacao.json), [respostas baseline](../frente_b/campanha_seguranca/golden_baseline_respostas.json) e [respostas final](../frente_b/campanha_seguranca/golden_final_respostas.json) |
| Golden v4 local | **23/35**, incluindo doze reprovações e um timeout de métrica: [notas](../frente_b/melhoria_qualidade_20260922/deepeval_candidata_v4.json), [respostas](../frente_b/melhoria_qualidade_20260922/golden_candidata_v4_respostas.json) e [análise](../frente_b/melhoria_qualidade_20260922/analise_qualidade_v4.json) |
| Red teaming baseline × final | **8 ataques bem-sucedidos → 0**: [baseline](../frente_b/campanha_seguranca/redteam_baseline.json), [final](../frente_b/campanha_seguranca/redteam_final.json) e [revisão](../frente_b/campanha_seguranca/revisao_redteam.json) |
| Red teaming v4 | Mesmos 20 ataques e cinco controles: [respostas](../frente_b/melhoria_qualidade_20260922/redteam_candidata_v4_respostas.json) e [revisão](../frente_b/melhoria_qualidade_20260922/revisao_redteam_candidata_v4.json) |
| AWS baseline — 35 sessões e 42 turnos | [Captura](../frente_a/golden_baseline_com_spans.json), [210 spans](../frente_a/spans_baseline_completo.json), [integrados](../frente_a/avaliacao_baseline_integrados.json) e [customizado](../frente_a/avaliacao_baseline_customizado.json). Médias por turno: Helpfulness 0,7005; Faithfulness 0,8274; customizado 42/42 PASS nas três regras. [Resumo e hashes](../frente_a/resumo_baseline.json). Final e red teaming AWS concluídos; veja os arquivos abaixo. |

Os 35 casos do golden permanecem intactos. A seleção atual contém 15 ataques; os logs originais ainda contêm os 20 executados. Rodar os 45 testes de código não cria novas avaliações dos modelos. Para a demonstração, mostre RT03 ou RT06 na [tabela de ataques](RED_TEAMING.md).

`resultados/frente_b/entrega_resumida/` e `revisao_trainee/` preservam verificações anteriores de oito e 77 testes. São histórico, não a suíte atual. Caminhos dentro de logs antigos descrevem o momento da execução e não foram reescritos.

A adaptação do capturador AWS para 15 ataques também foi verificada pela suíte de 45 testes, incluindo fluxo completo simulado golden/baseline/final, separação de sessões, erros e preservação de parâmetros. Veja [a validação](../frente_a/validacao_captura_redteam.json) e [o XML](../frente_a/validacao_captura_redteam.xml). Esse teste de código não executou ataques reais na AWS.

Red teaming AWS baseline: [15 ataques capturados](../frente_a/redteam_baseline.json), [80 spans](../frente_a/spans_redteam_baseline.json), [revisão de segurança](../frente_a/revisao_redteam_baseline.json) e [três avaliadores executados](../frente_a/avaliacao_redteam_baseline.json). O [resumo](../frente_a/resumo_avaliacao_redteam_baseline.json) explica o que cada avaliador detectou e deixou passar, incluindo o falso negativo do RT13.

## Fechamento das avaliações AWS

- Golden com seleção: [captura](../frente_a/golden_final_rag_seletivo.json), [spans](../frente_a/spans_final_rag_seletivo.json), [105 chamadas dos avaliadores](../frente_a/avaliacao_final_rag_seletivo.json) e [comparação das três rodadas](../frente_a/comparacao_golden_tres_rodadas.json).
- Red teaming final: [15 ataques](../frente_a/redteam_final.json), [96 spans](../frente_a/spans_redteam_final.json), [45 chamadas dos avaliadores](../frente_a/avaliacao_redteam_final.json), [notas baseline × final](../frente_a/comparacao_redteam.json) e [revisão por caso](../frente_a/revisao_redteam_final.json).
- Achados para a apresentação: golden 28 inventou espada; RT06 aceitou parcialmente a regra hostil; customizado deu PASS nesses casos porque não cobre essas falhas. Não confundir ausência de erro de execução com aprovação de qualidade.
