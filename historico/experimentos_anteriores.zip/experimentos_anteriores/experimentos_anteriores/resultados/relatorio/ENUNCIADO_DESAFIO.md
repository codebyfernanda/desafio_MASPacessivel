#### Desafio 2
No mês 1 você construiu e avaliou um chatbot local. Agora o nível sobe: você vai
construir um agente de verdade no AgentCore, avaliá-lo em duas frentes
(AgentCore Evaluations e DeepEval) e, o ponto central, tentar quebrá-lo com uma
campanha estruturada de red teaming. A ideia é aplicar tudo o que você viu nos
dois meses em uma única campanha de qualidade completa.
**1. Construção do agente.**
Suba um agente no AgentCore Harness. Escolha um domínio (você pode evoluir o
chatbot do mês 1 ou partir de um novo). O agente precisa ter:
- Instruções claras: papel, tom e regras ou limites de comportamento
- Pelo menos uma ferramenta real (Code Interpreter, Browser ou uma base de
conhecimento via RAG)
- Uma conversa multi-turno que use o contexto da sessão
Defina desde já o escopo, os riscos (o que seria uma falha grave desse agente) e
os thresholds que você vai adotar. Configure também o modelo juiz que vai usar
no DeepEval e nos avaliadores customizados do AgentCore: prefira o modelo mais
forte disponível, pois juízes fracos geram scores instáveis.
**2. Sessão exploratória.**
Explore o agente por 60 a 90 minutos com um charter simples, anotando
comportamentos suspeitos: respostas inventadas, promessas indevidas, falhas
de recusa, uso incorreto da ferramenta e vazamento de contexto entre turnos.
Essas descobertas devem orientar tanto o seu dataset quanto a sua campanha de
red teaming.
**3. Golden dataset.**
Monte um dataset com no mínimo 15 casos de teste, cobrindo as 5 categorias:
- Consulta direta (produto, informação, dado factual)
- Tarefa com ferramenta: caso que só passa se o agente acionar a ferramenta
corretamente
- Multi-turno: caso que depende do contexto acumulado ao longo de vários turnos
- Fora de escopo: perguntas que o agente deve recusar educadamente
- Adversarial: tentativas de induzir alucinação ou promessa indevida
Cada caso deve conter: input (ou a sequência de turnos), critério esperado e o
contexto de referência quando aplicável.
**4. Avaliação em duas frentes.**
Avalie o mesmo agente com os dois ecossistemas que você aprendeu.
- **Frente A, AgentCore Evaluations:**
Rode uma avaliação sobre as interações do agente com pelo menos 2 avaliadores
integrados e pelo menos 1 avaliador customizado (ou baseado em código) que
verifique uma regra específica do seu agente.
- **Frente B, DeepEval:**
implemente as três métricas mínimas, executando via pytest (`deepeval test
run`):
- Answer Relevancy ≥ 0,7: a resposta responde de fato à pergunta
- Faithfulness ≥ 0,8: a resposta é fiel ao contexto, sem informação inventada
- G-Eval de conformidade ≥ 0,8: uma regra do seu domínio (os critérios
acompanham os materiais)
Ao final, compare as duas frentes: o que cada uma pegou, seus pontos fortes e
seus limites.
**5. Campanha de red teaming.**
Esta é a parte central do desafio. Rode uma campanha estruturada de red teaming
contra o seu agente, usando as técnicas e ferramentas vistas no curso. Cubra no
mínimo 4 categorias de ataque, por exemplo:
- Prompt injection (direto e via ferramenta ou conteúdo consultado)
- Jailbreak ou bypass das regras do agente
- Vazamento de informação (system prompt, dados de outra sessão)
- Indução de conteúdo perigoso ou promessa indevida
- Uso indevido da ferramenta
Documente no mínimo 15 tentativas, cada uma com: objetivo do ataque, técnica
usada, resultado (o agente resistiu ou falhou) e severidade. Consolide em uma
tabela de achados (vulnerabilidade, severidade, evidência).
**6. Análise e correção.**
Analise as falhas das duas avaliações e da campanha de red teaming. Melhore o
agente onde fizer sentido: instruções ou prompt, guardrails e restrições da
ferramenta. Reexecute as avaliações e reteste as vulnerabilidades que você
encontrou. Compare baseline × versão final nas duas frentes (métricas e red
teaming).
**7. Relatório final (4 a 6 páginas).**
Documente: planejamento (escopo, riscos, thresholds), o agente (arquitetura:
modelo, ferramenta, memória), dataset e técnicas de design, resultados da
avaliação em duas frentes, campanha de red teaming e achados, análise baseline
× final e conclusão com uma avaliação de risco (você colocaria esse agente em
produção? por quê?).
## Entregáveis
1. Repositório (ou pasta) com o dataset, a suíte DeepEval, a configuração ou
código dos avaliadores do AgentCore, o log da campanha de red teaming e as
instruções de execução
2. Relatório final (4 a 6 páginas)
3. Apresentação de no máximo 6 minutos no demo day de encerramento
## Avaliação (100 pts)
- Agente no AgentCore + golden dataset: cobertura das categorias e uso das
técnicas de design (20 pts)
- Avaliação em duas frentes: AgentCore Evaluations + DeepEval implementados e
executando (25 pts)
- Campanha de red teaming: categorias cobertas, documentação e classificação
de severidade (30 pts)
- Análise e correção: baseline × final nas duas frentes (15 pts)
- Relatório e demo (10 pts)
**Mínimo para aprovação:**
agente rodando no AgentCore + pelo menos uma frente de avaliação funcionando
+ campanha de red teaming documentada com ≥ 15 tentativas + relatório
entregue.
