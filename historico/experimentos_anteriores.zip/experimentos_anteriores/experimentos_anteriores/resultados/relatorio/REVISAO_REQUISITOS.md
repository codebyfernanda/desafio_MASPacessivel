# Revisão dos requisitos do Desafio 2

Conferência em 24/09/2026 contra o PDF Desafio 2.pdf enviado pela autora (4 páginas; SHA-256 8ba1a78edece517247a404156ecee41e59a7688aeaff363c8014b1739f024319) e a transcrição ENUNCIADO_DESAFIO.md. “Documentado” indica evidência no pacote; não atribui pontos nem garante aceitação da banca.

| Requisito | Situação | Evidência / limite |
|---|---|---|
| Harness funcionando | Documentado | Capturas golden e redteam reais, versão 5 e versão 7, sessões e spans |
| Papel, tom e regras | Documentado | Prompts local/AWS, configuração registrada em src/agent_core/infra |
| Ferramenta real | Parcial | Gateway → Lambda → S3 foi executado pela aplicação; decisão autônoma de chamada pelo Gemma não observada |
| Memória multi-turno | Documentado com limite | Sete casos de dois turnos; session ID preservado; não é memória persistente entre usuários |
| Escopo e riscos | Documentado | Relatório, páginas 1 e 6; severidades no red teaming |
| Thresholds definidos | Parcial | DeepEval 0,7/0,8/0,8 preservados. AWS reporta médias; corte prévio de aprovação global não comprovado |
| Juiz forte configurado | Parcial | DeepSeek-R1 é o juiz atual. Não há estudo de que era o mais forte disponível; customizado AWS usa código, não LLM |
| Exploração de 60–90 minutos com charter | Parcial | Autora confirma exploração; 16 logs de 20/09 apoiam diagnóstico. Soma de runtimes (121,7 min) não prova duração contínua nem charter |
| Golden mínimo 15, cinco categorias | Documentado | 35 casos, sete por categoria, input/esperado/contexto |
| Caso só passa se ferramenta correta | Parcial | O extra Qwen verifica tool_calls. No Gemma A/B, há RAG da aplicação; as notas não comprovam escolha autônoma da ferramenta |
| Técnicas de design | Documentado | Partições por categoria, transição de contexto, premissas falsas e regras; exemplos na página 2 |
| Mesmo agente avaliado em A/B | Documentado para golden e ataques, com limites | Gemma baseline/final executados no DeepEval; Qwen é extra. Faithfulness baseline permanece não avaliável; ataques DeepEval concluídos |
| A: dois integrados + um customizado | Documentado e executado | Helpfulness, Faithfulness e MaspRegrasDeDominio; golden e ataques baseline/final |
| B: três métricas via Pytest/DeepEval | Executado no Gemma final | Final: AR 17/35, Faithfulness 32/35, G-Eval 18/35; baseline: AR 27/35, G-Eval 9/35 e Faithfulness não avaliável. Qwen é extra |
| Comando literal deepeval test run | Não comprovado nas rodadas Gemma | A suíte usa a biblioteca DeepEval e executa por python -m pytest. Isso comprova execução via Pytest, mas não o comando literal solicitado na página 2 do PDF; não alterar retrospectivamente a evidência |
| Comparação dos pontos fortes/limites A/B | Documentado | Página 5; não equipara médias AWS a aprovação conjunta local |
| Red teaming ≥4 categorias, ≥15 tentativas | Documentado | 15 ataques em cinco categorias; logs AWS reais e recorte local rastreável |
| Objetivo, técnica, resultado e severidade | Documentado | RED_TEAMING.md e revisao_redteam_final.json; RT06 classificado como falha parcial |
| Tabela vulnerabilidade/severidade/evidência | Documentado | RED_TEAMING.md, achados e correções; severidade potencial separada da falha comprovada |
| Técnicas/ferramentas vistas no curso | Parcial | Scripts Python, Pytest e técnicas descritas; material específico do curso não fornecido para conferência |
| Correções e retestes | Documentado | RAG, seleção de trechos, guardrails locais; rodada que piorou preservada |
| Baseline × final nas duas frentes | Parcial | AWS concluída; Qwen preservado como extra. Gemma/DeepEval: golden baseline/final concluídos; comparação Faithfulness incompleta sem contexto no baseline. Avaliação DeepEval dos 15 ataques Gemma concluída no baseline e no final |
| Relatório de 4–6 páginas | Documentado | PDF separado com seis páginas verificadas; Markdown/HTML no ZIP |
| Avaliação de risco/produção | Documentado | Página 6: não liberar sem supervisão e validações adicionais |
| Apresentação ≤6 minutos | Roteiro presente | DEMO_6_MINUTOS.md; apresentação/ensaio realizado não comprovado |
| Pasta com código, dados, logs e instruções | Presente | README, requisitos, src, tests, dados, resultados; ambiente e credenciais não incluídos |

## Conclusão da revisão

Os elementos centrais do mínimo de aprovação têm evidências: harness respondendo, avaliadores AWS funcionando, 15 ataques documentados e relatório entregue. A interpretação de “agente com ferramenta” e as lacunas acima precisam ser consideradas pela banca. O pacote não demonstra cumprimento integral dos 100 pontos.

A autora identificou a inconsistência com o item 4 e decidiu refazer a frente DeepEval usando as capturas imutáveis baseline/final do Gemma. Os resultados Qwen serão entregues como testes extras, sem alteração das notas nem troca do nome do agente. O adaptador foi preparado e validado. O baseline Gemma/DeepEval foi concluído e incorporado: 35 casos, AR 27/35, G-Eval 9/35, 35 registros de Faithfulness não avaliáveis, zero erros técnicos pendentes. O final foi concluído: AR 17/35, Faithfulness 32/35 e G-Eval 18/35, sem erros técnicos pendentes; 9/35 passaram nas três métricas. Faithfulness do baseline permanecerá não avaliável sem contexto recuperado registrado; essa limitação não será corrigida com a base atual.

A alternativa Qwen no Harness depende de endpoint compatível que ofereça a versão exata e de adaptação do fluxo. Usar outro Qwen ou outro prompt/RAG não reproduz automaticamente o agente local. Nenhuma alteração AWS foi feita nesta revisão.

## Aprendizado de QA: leitura e checagem de requisitos

A leitura atenta do enunciado e a checagem entre o requisito e o trabalho realizado permitiram à autora identificar um erro substancial enquanto ainda havia tempo para corrigi-lo. Avaliar Gemma em uma frente e Qwen na outra produzia resultados reais, mas não atendia à exigência de avaliar o mesmo agente. Essa revisão evitou apresentar uma comparação inadequada como requisito cumprido e orientou a nova execução DeepEval sobre as capturas Gemma. O aprendizado é que a qualidade depende também de conferir o objetivo dos testes, e não apenas de executá-los. O trabalho Qwen permanece como extra, com seus resultados preservados. Detectar o erro a tempo é um avanço de QA; golden e ataques do mesmo agente têm baseline/final nas duas frentes. A comparação de Faithfulness continua limitada pela ausência de fontes no baseline.

## Itens 6 e 7: rastreabilidade por palavras-chave

- **Análise de falhas, instruções/prompt, guardrails e restrições da ferramenta:** página 5.
- **Reexecução, reteste de vulnerabilidades e baseline × versão final (métricas e red teaming):** páginas 3–5; golden e ataques Gemma/DeepEval concluídos, com comparação parcial pela falta de fontes no baseline.
- **Planejamento, escopo, riscos e thresholds:** páginas 1 e 3.
- **Arquitetura: modelo, ferramenta e memória; dataset, categorias e técnicas de design:** página 2.
- **Campanha de red teaming, ≥ 15 tentativas, documentação, achados e classificação de severidade:** página 4.
- **Conclusão e avaliação de risco: colocaria em produção? Por quê?:** página 6.
- **Entregáveis: pasta/repositório, relatório de 4–6 páginas e demo de no máximo 6 minutos:** página 6.
- **Critérios de avaliação: 20 + 25 + 30 + 15 + 10 = 100 pontos possíveis:** página 1; não representa nota atribuída.
- **Mínimo de aprovação: agente AgentCore funcionando, ao menos uma avaliação funcionando, ≥ 15 tentativas documentadas e relatório entregue:** página 6.

## Red teaming DeepEval concluído

A suíte avaliar_redteam_gemma.py valida e avalia as capturas de 15 ataques Gemma por versão, sem novas chamadas AWS. Os critérios defensivos estão em criterios_redteam_gemma.json; são iguais para baseline/final e não alteram o payload nem os IDs dos logs originais. Onze verificações offline passaram e os 45 testes de código existentes passaram novamente. Na execução posterior pela autora, os dois arquivos foram concluídos e conferidos: 45 registros por versão, zero erros técnicos, AR 6/15 → 6/15, G-Eval 5/15 → 8/15, Faithfulness não avaliável → 15/15. O final tem 13 casos reprovados em alguma métrica e dois aprovados nas três. Esses números não são contagem de vulnerabilidades. RT08 e RT10 mostram erros do juiz; RT12 revela limite de Faithfulness. Veja [comparação com hashes](../frente_b/gemma/comparacao_redteam.json).


## Conclusões de QA apoiadas nas evidências

Todos os tópicos foram abordados na documentação, mas os requisitos parciais da tabela não devem ser apresentados como integralmente comprovados. Falha de um caso não significa, por si só, falta de execução da campanha: registrar defeitos e regressões faz parte do objetivo do desafio.

| Aprendizado | Evidência concreta | Aplicação em próximos projetos |
|---|---|---|
| Leitura e rastreabilidade previnem testar o objetivo errado | A autora identificou a divergência Gemma × Qwen no item 4 | Relacionar requisito, caso, critério de aceitação e log desde o planejamento |
| Melhoria exige regressão | G-Eval golden 9/35 → 18/35; relevância 27/35 → 17/35 | Retestar critérios separados, sem esconder perdas; mudar uma variável por vez quando possível |
| Juiz automático não é verdade absoluta | RT08 exige ação proibida; RT12 tem Faithfulness 1 com afirmação sem fonte | Calibrar com revisão humana, registrar divergência sem editar notas antigas |
| Teste de código, nota de resposta e segurança têm objetivos distintos | 45 testes de código, 35 golden e 15 ataques; final RT com 13 failed | Informar denominador e significado de cada resultado; não converter falhas de métricas em vulnerabilidades |
| Evidência deve ser planejada antes da execução | Faithfulness baseline sem contexto; JSONL e hashes preservam as rodadas | Registrar versão, entrada, fonte, resposta, parâmetros e resultado; ausência vira não avaliável |
| Priorização depende do risco ao usuário | RT06 aceita regra hostil; golden 28 inventa descrição | Corrigir recusas e fatos; validar acessibilidade e atacar cenários novos antes de produção |
| Frentes complementares aumentam a capacidade de investigação | AWS associa traces; DeepEval permite inspecionar critérios/vereditos | Comparar caso a caso e explicar limites; não somar médias de escalas e denominadores distintos |

Conclusão: a entrega tem evidências dos elementos mínimos, mas não comprova todos os requisitos de forma integral nem garante 100 pontos. O protótipo permanece indicado para demonstração supervisionada, com falhas e limitações explícitas.
