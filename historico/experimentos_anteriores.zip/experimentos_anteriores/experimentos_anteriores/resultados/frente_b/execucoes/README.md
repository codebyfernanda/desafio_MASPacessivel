# Novas execuções locais

Os comandos de [executar.py](../../../executar.py) gravam novos logs aqui, sem substituir os resultados anteriores. Siga o [guia inicial](../../../README.md).

A cópia `prompt_de_sistema_inicial.md` que já estava nesta pasta foi preservada. O agente usa `src/agente/prompt_de_sistema_inicial.md`; editar esta cópia não muda o agente.
