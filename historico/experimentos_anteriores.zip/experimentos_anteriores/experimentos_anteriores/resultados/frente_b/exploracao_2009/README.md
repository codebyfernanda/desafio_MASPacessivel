# Exploração e diagnóstico de 20/09/2026

A autora confirmou que realizou exploração e forneceu estes 16 logs. Eles documentam tentativas de avaliação e diagnóstico: 11 têm resultados e cinco não contêm casos. O log 202206 contém somente 34 dos 35 casos. Os rótulos de modelo são do juiz registrado, não prova da versão do agente respondente.

As durações somam aproximadamente **121,7 minutos de execução registrada**. Não são comprovação de uma sessão exploratória contínua de 60–90 minutos: podem existir intervalos, sobreposição e tempo de avaliação automatizada. A duração exata da exploração humana e seu charter contemporâneo não estão registrados nesses JSONs. A data de 20/09 é indicada pelos nomes; a maioria dos arquivos não tem timestamp completo nos metadados.

## Leia primeiro

- [deepeval_log_2009_014206.json](logs/deepeval_log_2009_014206.json): Contém respostas do agente e 35 casos: permite inspecionar comportamento, além das notas.
- [deepeval_log_2009_191547.json](logs/deepeval_log_2009_191547.json): Mostra transição para resultados parciais com o juiz Llama 3.2; contraste com erros iniciais.
- [deepeval_log_2009_202206.json](logs/deepeval_log_2009_202206.json): Rodada incompleta de 34 casos: exemplo de execução que não deve ser contada como golden completo.
- [deepeval_log_2009_211506.json](logs/deepeval_log_2009_211506.json): Experimento com juiz Llama 3.1 e maior duração individual, sem apagar as tentativas anteriores.

## Achados que podem ser sustentados

- Mudanças de juiz entre DeepSeek-R1, Llama 3.2 e Llama 3.1; não são uma única comparação com juiz fixo.
- Há respostas inválidas para o formato JSON esperado e notas baixas. Erro do juiz não comprova que o agente falhou em todos os casos.
- Rodadas vazias ou incompletas não demonstram cobertura de 35 casos.
- O registro 014206 inclui actual_output; nos demais, a ausência desse campo limita a revisão direta da resposta do agente.

A seleção acima prioriza diversidade de evidência (respostas, diagnóstico, rodada incompleta e mudança de juiz), não maior taxa de aprovação. Todos os 16 originais permanecem em logs/ e seus hashes estão em inventario.json. Eles não substituem os baselines e retestes da campanha final, nem provam que o mesmo agente foi avaliado nas frentes A/B.
