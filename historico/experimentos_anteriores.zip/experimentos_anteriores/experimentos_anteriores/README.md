# MASP Acessível — Fernanda Bastos

**Atualização da frente B:** o agente principal é Gemma nas duas frentes. Baseline e final DeepEval foram concluídos (35 casos cada). Qwen é o agente do estudo extra, DeepSeek-R1 é o juiz local e DeepEval é a biblioteca. Veja [instruções Gemma](GEMMA_NO_DEEPEVAL.md) e [relatório](resultados/relatorio/RELATORIO.md). A avaliação DeepEval dos 15 ataques Gemma foi concluída no baseline e no final, com zero erros técnicos. Veja a [comparação dos ataques](resultados/frente_b/gemma/comparacao_redteam.json).

Guia de estudo em QA: verificar se o agente responde com clareza, usa as fontes do MASP e respeita suas regras.

## Organização

```text
Desafio 2/
├── dados/                       base RAG, manifesto, golden (35) e ataques (15)
├── resultados/
│   ├── relatorio/               relatório, logs, red teaming e demo
│   ├── frente_a/                evidências AWS baseline e final
│   └── frente_b/                baseline, final e verificações locais
├── src/
│   ├── agente/                  chatbot local, RAG e proteções
│   ├── agent_core/              Frente A: captura e avaliadores AWS
│   ├── deepeval/                Frente B: juiz e métricas
│   └── executar_campanha.py
├── tests/
│   ├── test_agentcore.py        15 testes de código
│   ├── test_deepeval.py         15 testes de código
│   ├── test_integracao.py       15 testes de integração local
│   └── deepeval/               runners do golden completo
├── .gitignore
├── executar.py
├── pytest.ini
├── README.md
└── requirements.txt
```

Comece pela [revisão dos requisitos](resultados/relatorio/REVISAO_REQUISITOS.md): o golden do Gemma foi avaliado em A/B, com Faithfulness baseline não avaliável. Golden e ataques foram avaliados nas duas frentes; as notas e limitações são preservadas.

Leia o [relatório](resultados/relatorio/RELATORIO.md) e o [guia dos 45 testes e logs](resultados/relatorio/LOGS_ESSENCIAIS.md). O [mapa do código](src/README.md) explica para que servem os arquivos. `dados/base_conhecimento_manifesto.json` verifica alterações na base e é necessário ao agente.

## Preparar e executar

Abra esta pasta extraída no VS Code. No terminal PowerShell da raiz, prepare uma vez:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Depois escolha um comando:

| Quero… | Comando |
|---|---|
| Rodar os 45 testes de código | `.\.venv\Scripts\python.exe executar.py testes` |
| Conversar com o guia | `.\.venv\Scripts\python.exe executar.py conversar` |
| Consultar a avaliação registrada | `.\.venv\Scripts\python.exe executar.py resultados` |
| Avaliar o golden completo de 35 casos | `.\.venv\Scripts\python.exe executar.py avaliar` |
| Capturar as 15 tentativas de ataque | `.\.venv\Scripts\python.exe executar.py redteam` |

Os 45 testes usam simulações e não exigem Ollama ou login AWS. Para conversar, mantenha Ollama ativo com `qwen2.5:7b`; para avaliar, também com `deepseek-r1:latest`. A avaliação pode levar horas. Novos logs ficam em `resultados/frente_b/execucoes/`. As capturas de ataques precisam ser revisadas antes de classificar sucesso ou resistência.

## Não confunda as três verificações

- **45 testes de código:** verificam regras, integração e regressões, isto é, comportamentos que podem quebrar após uma mudança.
- **35 casos do golden:** medem a qualidade das respostas com modelos reais. O golden foi preservado integralmente.
- **15 tentativas de red teaming:** procuram violações de regras em cinco categorias. Os cinco controles benignos antigos ficam como apoio, fora dessa execução.

RAG significa busca nas fontes. Guardrail é uma regra de proteção. Threshold é a nota mínima de uma métrica. Baseline × final compara antes e depois das correções. Log é a evidência da execução.

## Estado da entrega

DeepEval registrado: baseline **28/35**, final anterior **21/35**, v4 **23/35 (65,7%)**. Ataques conhecidos bem-sucedidos: **8 → 0**. A reorganização não gera novas notas dos modelos.

A [Frente A](src/agent_core/README.md) tem harness respondendo, golden de 35 casos e 15 ataques executados e avaliados no baseline e no final por dois integrados e um customizado. O [relatório](resultados/relatorio/RELATORIO.md) compara as versões e as duas frentes, preservando falhas e limites.

Os requisitos e pesos estão no relatório. A [demo de seis minutos](resultados/relatorio/DEMO_6_MINUTOS.md), a documentação dos 15 ataques selecionados, as fontes de pesquisa e os agradecimentos estão incluídos. Temperaturas, thresholds e demais parâmetros não foram alterados.

A seleção atual mantém 15 ataques, incluindo as oito falhas históricas. Os logs originais de 20 e o recorte anterior de 19 permanecem como histórico. O relatório identifica o recorte de 15 sem apresentá-lo como uma nova execução.


## Cronograma de desenvolvimento e implantação

Este é o planejamento informado para setembro de 2026, não uma declaração de que todas as etapas foram concluídas. O baseline da Frente A foi concluído em 23/09: 35 sessões avaliadas por dois integrados e um customizado. Red teaming e comparações finais AWS também foram concluídos; os horários efetivos estão nos logs.

| Data | Etapa | Atividades planejadas |
|---|---|---|
| 16/09 (Qua) | Construção do agente | AgentCore, limites, RAG e documentação de riscos |
| 17/09 (Qui) | Exploração e golden | Exploração e 35 casos nas cinco categorias |
| 18/09 (Sex) | Frente A | Avaliadores integrados e customizado de domínio — baseline executado em 23/09 |
| 19/09 (Sáb) | Frente B | Pytest e métricas Answer Relevancy, Faithfulness e G-Eval |
| 21/09 (Seg) | Red teaming e correções | Ataques, análise de falhas, guardrails e comparação antes/depois |
| 22/09 (Ter) | Repositório e relatório | Organização, arquitetura, evidências e resultados |
| 23/09 (Qua) | Revisão de qualidade | Conferência dos arquivos e requisitos |
| 24/09 (Qui) | Code freeze e demo | Congelamento de código/prompt e ensaio com autodescrição |
| 25/09 (Sex) | Apresentação | Demonstração do protótipo e de seus limites |

## Sobre a estrutura

A organização segue a referência fornecida do [Desafio 1](https://github.com/codebyfernanda/desafio-cosmeticbot). Mantive `src/agente/` separado para deixar claro que o Qwen local não é o harness AWS. `.venv`, `.deepeval` e caches são criados pelas ferramentas e não acompanham o ZIP.

As medições anteriores ficam preservadas em `resultados/frente_b/`; não substitua uma baseline por uma nova rodada. Na AWS, os baselines, a rodada intermediária e os retestes finais estão preservados; não repetir campanhas para alterar a numeração ou substituir notas. Consulte o [guia da Frente A](src/agent_core/README.md). A baseline comparada neste relatório é a da campanha documentada, não uma medição de agosto presumida a partir do projeto anterior.


## Relatório e abertura do pacote

O ZIP é compactado: extraia-o no Explorador de Arquivos e abra a pasta extraída no VS Code. Os arquivos internos são texto UTF-8, sem ambientes virtuais ou caches. O manifesto da base e a pasta entrega_resumida foram preservados.

O relatório em `resultados/relatorio/RELATORIO.html` pode ser aberto no navegador; o arquivo Markdown é editável no VS Code. O PDF de seis páginas acompanha a entrega separadamente. A paginação validada é a do PDF; configurações de impressão do navegador podem mudá-la.

Os 16 logs fornecidos de 20/09 estão em `resultados/frente_b/exploracao_2009/`, com quatro indicados para leitura inicial e um inventário de todos. Não são descartados por nota baixa.

## Comandos adicionais

A dependência AWS foi incluída em requirements.txt. AWS CLI e Ollama são programas externos; não acompanham o ZIP. Use um perfil já autorizado para a conta do projeto. Não coloque credenciais nos arquivos.

Para executar a suíte DeepEval pelo comando solicitado no desafio, em ambiente preparado e com Ollama ativo:

```powershell
.\.venv\Scripts\deepeval.exe test run tests/deepeval/run_baseline.py
```

Esse comando executa o agente local atual e novas avaliações; não reproduz automaticamente o snapshot histórico do baseline. Preserve os resultados antigos. Para as capturas Gemma, use a suíte específica já executada no golden. Os ataques também estão concluídos; o [guia dos 15 ataques](REDTEAM_GEMMA_NO_DEEPEVAL.md) documenta a execução. Não sobrescreva as rodadas já salvas.

A versão confirmada da biblioteca é DeepEval 4.2.3; agente local qwen2.5:7b; juiz atual deepseek-r1:latest. Logs antigos experimentaram outros juízes. Trocar juiz entre rodadas impede atribuir a mudança da nota somente ao agente.

**Próxima execução:** [15 ataques Gemma no DeepEval](REDTEAM_GEMMA_NO_DEEPEVAL.md), com respostas AWS congeladas e critérios defensivos iguais no baseline e no final. Não reexecute os 35 casos apenas para tentar melhorar notas.
