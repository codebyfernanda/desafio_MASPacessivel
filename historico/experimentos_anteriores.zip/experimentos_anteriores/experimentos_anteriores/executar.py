"""Entrada do projeto: escolha uma tarefa sem memorizar os scripts internos."""

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
RESULTADOS = RAIZ / "resultados/frente_b"


def mostrar_resultados():
    """Lê a avaliação registrada; consultar resultados não executa modelos."""
    caminho = RESULTADOS / "melhoria_qualidade_20260922/deepeval_candidata_v4.json"
    registro = json.loads(caminho.read_text(encoding="utf-8"))
    casos = registro["resultados"]
    aprovados = sum(caso["sucesso"] for caso in casos)
    print(f"Golden v4 registrado: {aprovados}/{len(casos)} aprovados.")
    print("Esta é uma medição histórica, anterior à simplificação do código.")
    print(f"Notas e justificativas: {caminho}")
    print(f"Comparação e limites: {RAIZ / 'resultados/relatorio/RELATORIO.md'}")
    print("AWS: execução dos avaliadores pendente; acesso GetHarness negado.")


def main():
    argumentos = argparse.ArgumentParser(description=__doc__)
    argumentos.add_argument(
        "tarefa", nargs="?",
        choices=["testes", "conversar", "avaliar", "redteam", "resultados"],
        help="testes: 45 verificações de código; avaliar: 35 casos com modelos reais",
    )
    tarefa = argumentos.parse_args().tarefa
    if tarefa is None:
        argumentos.print_help()
        return 0
    if tarefa == "resultados":
        mostrar_resultados()
        return 0

    # Cada execução recebe um nome novo para preservar as evidências anteriores.
    pasta_saida = RESULTADOS / "execucoes"
    pasta_saida.mkdir(parents=True, exist_ok=True)
    instante = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    comandos = {
        "testes": ["-m", "pytest", "tests/test_integracao.py", "tests/test_deepeval.py", "tests/test_agentcore.py", "-q",
                   f"--junitxml={pasta_saida / ('testes_' + instante + '.xml')}"],
        "conversar": ["-m", "src.agente.main"],
        "avaliar": ["-m", "pytest", "tests/deepeval/run_baseline.py", "-v"],
        "redteam": ["src/executar_campanha.py", "--versao", "final",
                    "--tipo", "redteam", "--saida",
                    str(pasta_saida / ("redteam_" + instante + ".json"))],
    }
    if tarefa in ("avaliar", "redteam"):
        print("Execução com modelos reais. Aguarde; os logs serão preservados.", flush=True)
    if tarefa == "redteam":
        print("Revise cada resposta: capturar ataques não significa classificá-los.", flush=True)

    ambiente = os.environ.copy()
    ambiente["DEEPEVAL_TELEMETRY_OPT_OUT"] = "YES"
    ambiente["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    # O mesmo Python do comando inicial evita trocar de ambiente sem perceber.
    resultado = subprocess.run(
        [sys.executable, *comandos[tarefa]], cwd=RAIZ, env=ambiente, check=False,
    )
    return resultado.returncode


if __name__ == "__main__":
    raise SystemExit(main())
