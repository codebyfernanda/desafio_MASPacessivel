"""Recupera a base do MASP no S3 para uma ferramenta do AgentCore Gateway.

Recuperação integral de um documento pequeno; não usa busca vetorial.
O modelo recebe dados de referência, nunca novas instruções de sistema.
"""

import hashlib

import boto3


NOME_BUCKET = "masp-rag-base-conhecimento-fernandab-024687770728-sa-east-1-an"
CHAVE_BASE = "masp_base_conhecimento.txt"

# Reutilizar o cliente evita abrir uma conexão para cada chamada da Lambda.
cliente_s3 = boto3.client("s3")


def ler_base() -> dict:
    """Lê somente a fonte definida pelo projeto e identifica seus bytes."""
    resposta = cliente_s3.get_object(Bucket=NOME_BUCKET, Key=CHAVE_BASE)
    try:
        conteudo = resposta["Body"].read()
    finally:
        resposta["Body"].close()

    texto = conteudo.decode("utf-8-sig")
    if not texto.strip():
        raise ValueError("A base de conhecimento está vazia.")

    # O hash permite conferir qual base foi usada em cada avaliação.
    return {
        "fonte": f"s3://{NOME_BUCKET}/{CHAVE_BASE}",
        "sha256": hashlib.sha256(conteudo).hexdigest(),
        "versao_s3": resposta.get("VersionId"),
        "conteudo": texto,
    }


def lambda_handler(evento, contexto):
    """Recebe os argumentos da ferramenta e devolve dados em JSON."""
    if not isinstance(evento, dict) or set(evento) != {"consulta"}:
        raise ValueError("Informe apenas o campo consulta.")
    consulta = evento["consulta"]
    if not isinstance(consulta, str) or not consulta.strip():
        raise ValueError("A consulta deve ser um texto não vazio.")

    # A consulta não pode escolher bucket, arquivo, URL ou comando.
    # Erros de leitura se propagam: uma falha não deve parecer uma consulta válida.
    return ler_base()
