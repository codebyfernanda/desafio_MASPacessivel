# Configuração AWS registrada

Esta pasta reúne o código da Lambda RAG e as configurações usadas na integração. Não execute os JSONs como comandos; os recursos já existem na conta do projeto.

- `lambda_function.py`: código da Lambda `ler-rag-s3-masp`; handler `lambda_function.lambda_handler`, Python 3.14. Lê uma chave S3 fixa e fecha o corpo da resposta. O parâmetro consulta não seleciona caminhos nem executa código.
- `gateway.json` e `ferramenta.json`: Gateway IAM/MCP e target Lambda. IDs e conta são específicos deste projeto.
- Políticas JSON: confiança e permissões usadas na integração. A role de execução da Lambda também precisa de `s3:GetObject` no objeto fixo; não há aqui um provisionador automático completo.
- `harness_v7_registrado.json`: snapshot histórico do harness e endpoint durante diagnóstico. Não contém credenciais de login.

O fluxo efetivamente medido usa `rag_gateway.py` para consultar Gateway/Lambda/S3 antes de `InvokeHarness`; `selecionar_trechos.py` reduz o contexto. O Gemma não executou a ferramenta autonomamente nos spans inspecionados. O código da Lambda do avaliador é diferente: `../lambda_avaliador.py`.
