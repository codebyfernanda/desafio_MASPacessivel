"""Recuperação explícita: Gateway -> Lambda -> S3 antes de chamar o harness."""
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone
from src.agent_core.selecionar_trechos import selecionar, referencia
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.httpsession import URLLib3Session

REGIAO = "sa-east-1"
GATEWAY_ID = "masp-rag-f0vkhsdstj"
URL_GATEWAY = "https://masp-rag-f0vkhsdstj.gateway.bedrock-agentcore.sa-east-1.amazonaws.com/mcp"
FONTE_ESPERADA = "s3://masp-rag-base-conhecimento-fernandab-024687770728-sa-east-1-an/masp_base_conhecimento.txt"

def interpretar_resposta(texto, identificador):
    """Aceita JSON ou eventos SSE, exigindo a resposta da chamada enviada."""
    if texto.lstrip().startswith("{"):
        mensagens = [json.loads(texto)]
    else:
        mensagens = []
        for bloco in texto.replace("\r\n", "\n").split("\n\n"):
            dados = "\n".join(linha[5:].lstrip() for linha in bloco.splitlines() if linha.startswith("data:"))
            if dados and dados != "[DONE]":
                mensagens.append(json.loads(dados))
    respostas = [item for item in mensagens if item.get("id") == identificador]
    if len(respostas) != 1:
        raise ValueError("O Gateway não retornou uma resposta única para esta chamada.")
    resposta = respostas[0]
    if "error" in resposta or "result" not in resposta:
        raise ValueError(f"Erro MCP: {resposta.get('error', 'resultado ausente')}")
    return resposta["result"]


def chamar_mcp(sessao, transporte, versao, metodo, parametros, registro):
    """Assina cada requisição com o perfil AWS; não grava credenciais nos logs."""
    identificador = len(registro["chamadas"]) + 1
    corpo = json.dumps({"jsonrpc": "2.0", "id": identificador, "method": metodo, "params": parametros}).encode("utf-8")
    requisicao = AWSRequest(method="POST", url=URL_GATEWAY, data=corpo, headers={
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream",
        "MCP-Protocol-Version": versao,
    })
    credenciais = sessao.get_credentials()
    if credenciais is None:
        raise ValueError("O perfil não forneceu credenciais AWS.")
    SigV4Auth(credenciais.get_frozen_credentials(), "bedrock-agentcore", REGIAO).add_auth(requisicao)
    resposta = transporte.send(requisicao.prepare())
    texto = resposta.content.decode("utf-8")
    registro["chamadas"].append({"metodo": metodo, "http_status": resposta.status_code, "corpo": texto})
    if resposta.status_code != 200:
        raise ValueError(f"Gateway retornou HTTP {resposta.status_code}; veja o diagnóstico salvo.")
    return interpretar_resposta(texto, identificador)


def extrair_documento(resultado):
    """Falha da ferramenta não pode ser tratada como documento recuperado."""
    if resultado.get("isError"):
        raise ValueError("A ferramenta sinalizou erro; veja a resposta no diagnóstico.")
    candidatos = [resultado.get("structuredContent")]
    for item in resultado.get("content", []):
        if item.get("type") == "text":
            try:
                candidatos.append(json.loads(item["text"]))
            except json.JSONDecodeError:
                continue
    documentos = [item for item in candidatos if isinstance(item, dict) and {"fonte", "sha256", "conteudo"} <= item.keys()]
    if not documentos:
        raise ValueError("A ferramenta não retornou o documento no formato esperado.")
    if any(item != documentos[0] for item in documentos[1:]):
        raise ValueError("Respostas estruturada e textual divergentes.")
    return documentos[0]


class RagMasp:
    """Consulta a fonte fixa. Nunca executa texto produzido pelo modelo."""

    def __init__(self, sessao, controle, pasta_dados):
        self.sessao = sessao
        manifesto = json.loads((pasta_dados / "base_conhecimento_manifesto.json").read_text(encoding="utf-8-sig"))
        self.hash_base = manifesto["sha256"]
        if hashlib.sha256((pasta_dados / "base_conhecimento_rag.md").read_bytes()).hexdigest() != self.hash_base:
            raise ValueError("A base local difere do manifesto. Revisar antes da captura.")
        gateway = controle.get_gateway(gatewayIdentifier=GATEWAY_ID)
        if (gateway["status"] != "READY" or gateway["gatewayUrl"] != URL_GATEWAY
                or gateway["authorizerType"] != "AWS_IAM"):
            raise ValueError("Gateway indisponível ou diferente do esperado.")
        versoes = gateway.get("protocolConfiguration", {}).get("mcp", {}).get("supportedVersions") or ["2025-03-26"]
        self.versao = next((v for v in ("2025-03-26", "2025-06-18", "2025-11-25") if v in versoes), None)
        if self.versao is None:
            raise ValueError("Versão MCP não suportada. Não iniciar a captura.")
        self.metadados = {
            "fluxo": "recuperacao_na_aplicacao_antes_do_harness",
            "gateway_id": GATEWAY_ID, "fonte": FONTE_ESPERADA,
            "base_sha256": self.hash_base, "versao_mcp": self.versao,
            "ferramenta": "base-masp___RAG_MASP",
            "codigo_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "selecao": "trechos_literais_por_titulo_artista_e_contexto_da_sessao",
            "seletor_sha256": hashlib.sha256(Path(__file__).with_name("selecionar_trechos.py").read_bytes()).hexdigest(),
            "limite": "Chamada pelo perfil da aplicação; não é ferramenta executada autonomamente pelo Gemma nem span interno do harness.",
        }

    def recuperar(self, pergunta, registro, anteriores=()):
        registro.update(inicio=datetime.now(timezone.utc).isoformat(), status="em_execucao", chamadas=[])
        transporte = URLLib3Session()
        try:
            resultado = chamar_mcp(self.sessao, transporte, self.versao, "tools/call", {
                "name": self.metadados["ferramenta"], "arguments": {"consulta": pergunta}
            }, registro)
            documento = extrair_documento(resultado)
            if (documento["fonte"] != FONTE_ESPERADA or documento["sha256"] != self.hash_base
                    or hashlib.sha256(documento["conteudo"].encode("utf-8")).hexdigest() != self.hash_base):
                raise ValueError("O documento remoto difere da base autorizada. Não chamar o modelo.")
            # Não recebe gabarito, categoria, pontuação ou resposta esperada do dataset.
            trechos = selecionar(documento["conteudo"], pergunta, anteriores)
            documentos = [{"referencia": referencia(t), "conteudo": t,
                           "base_sha256": self.hash_base,
                           "trecho_sha256": hashlib.sha256(t.encode("utf-8")).hexdigest()}
                          for t in trechos]
            registro["documentos_recuperados"] = documentos
            mensagem = json.dumps({"pergunta": pergunta,
                                   "documentos_recuperados": documentos}, ensure_ascii=False)
            registro.update(status="recuperado", base_sha256=self.hash_base,
                            mensagem_sha256=hashlib.sha256(mensagem.encode("utf-8")).hexdigest())
            return mensagem
        except Exception as erro:
            registro.update(status="erro", erro=f"{type(erro).__name__}: {erro}")
            raise
        finally:
            transporte.close()
            registro["fim"] = datetime.now(timezone.utc).isoformat()
