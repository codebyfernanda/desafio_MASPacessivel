"""Seleciona trechos literais por título/artista; não acessa gabaritos ou modelos."""
import re
import unicodedata


def normalizar(texto):
    return ''.join(c for c in unicodedata.normalize('NFD', texto.casefold()) if unicodedata.category(c) != 'Mn')


def selecionar(conteudo, pergunta, anteriores=()):
    partes = re.split(r'(?=\*\*Obra \d+:)', conteudo)
    obras = partes[1:]
    consulta = normalizar(pergunta)
    escolhidas = []
    for obra in obras:
        cabecalho = re.match(r'\*\*Obra \d+:\s*(.*?)\*\*', obra)
        artista = re.search(r'\*\*Artista:\*\*\s*([^\r\n]+)', obra)
        if not cabecalho or not artista:
            raise ValueError('A base contém uma obra sem título ou artista reconhecível.')
        titulo = normalizar(cabecalho.group(1).strip())
        nomes = {titulo, titulo.rstrip('?!'), titulo.split(' [')[0], normalizar(artista.group(1).rstrip('.'))}
        if any(nome and re.search(r'(?<!\w)' + re.escape(nome) + r'(?!\w)', consulta) for nome in nomes):
            escolhidas.append(obra)
        elif 'profecias' in consulta and 'profecias' in titulo:
            escolhidas.append(obra)
    if not escolhidas and re.search(r'\b(dele|dela|nele|nela|mulher|figura|mesma artista|outra obra|comparar)\b', consulta):
        escolhidas = [obra for obra in anteriores if obra in obras]
    if re.search(r'mesma artista|outra obra', consulta):
        for obra in list(escolhidas):
            artista = re.search(r'\*\*Artista:\*\*\s*([^\r\n]+)', obra).group(1)
            escolhidas.extend(o for o in obras if f'**Artista:** {artista}' in o and o not in escolhidas)
    return escolhidas or [partes[0]]


def referencia(trecho):
    titulo = re.match(r'\*\*(Obra \d+:.*?)\*\*', trecho)
    return titulo.group(1) if titulo else 'Informações gerais do museu'
