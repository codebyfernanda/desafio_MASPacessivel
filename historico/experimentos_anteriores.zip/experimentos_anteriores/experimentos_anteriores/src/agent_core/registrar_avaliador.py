# Estudo: nomes claros, responsabilidades explícitas e comentários sobre decisões.
# O registro usa uma Lambda já publicada e autorizada. Este script
# não cria permissões nem considera configuração como evidência de execução.

"""Registra avaliador codeBased após a Lambda e sua permissão de invocação existirem."""
import argparse, json
from pathlib import Path

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--lambda-arn', required=True)
    p.add_argument('--nome', default='MaspRegrasDeDominio')
    p.add_argument('--region', default='sa-east-1')
    p.add_argument('--profile')
    p.add_argument('--saida', type=Path, required=True)
    argumentos_cli = p.parse_args()
    if argumentos_cli.saida.exists():
        raise SystemExit('O registro já existe; não crie duplicatas.')
    if not argumentos_cli.lambda_arn.startswith(f'arn:aws:lambda:{argumentos_cli.region}:'):
        raise SystemExit('A Lambda deve estar na mesma região da avaliação.')
    import boto3
    cliente_servico = boto3.Session(profile_name=argumentos_cli.profile, region_name=argumentos_cli.region).client('bedrock-agentcore-control')
    resultado_servico = cliente_servico.create_evaluator(evaluatorName=argumentos_cli.nome, level='TRACE', evaluatorConfig={'codeBased': {'lambdaConfig': {'lambdaArn': argumentos_cli.lambda_arn, 'lambdaTimeoutInSeconds': 60}}})
    argumentos_cli.saida.parent.mkdir(parents=True, exist_ok=True)
    argumentos_cli.saida.write_text(json.dumps(resultado_servico, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    print('Avaliador registrado:', resultado_servico.get('evaluatorId'))
if __name__ == '__main__':
    main()
