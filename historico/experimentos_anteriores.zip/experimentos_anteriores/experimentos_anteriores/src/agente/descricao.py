# Estudo: nomes claros, responsabilidades explícitas e comentários sobre decisões.
# O extrator preserva a descrição documentada. Quando a regra não cobre
# a pergunta, retorna None para o chamador escolher o próximo tratamento.

"""Preserva descrições cadastradas, incluindo peças de vestuário do acervo."""
import re
from .rag import normalizar


def responder_descricao_cadastrada(pergunta, documentos):
    pergunta_normalizada = normalizar(pergunta).strip()
    obras = [documento for documento in documentos if re.match(r'^\*\*Obra \d+:', documento)]
    if len(obras) != 1:
        return None
    obra = obras[0]
    tecnica = re.search(r'^\* \*\*Técnica:\*\* (.+)$', obra, re.MULTILINE)
    categoria = normalizar(tecnica.group(1)).strip().rstrip('.') if tecnica else ''
    peca_vestuario = bool(re.search(r'\((vestido|roupa|traje|indumentaria)\)$', categoria))
    pergunta_visual = bool(re.search(r'^(como (e|sao)|descreva)\b|detalhes visuais|aparencia|textura|cores', pergunta_normalizada))
    pergunta_metadados = bool(re.search(r'\b(quem|autor|autora|artista|quando|tecnica|materiais)\b|em que ano', pergunta_normalizada))
    consulta_peca = (peca_vestuario and pergunta_visual and not pergunta_metadados
                     and re.search(r'\b(roupas?|vestidos?|trajes?|indumentaria)\b', pergunta_normalizada))
    if not re.match(r'^descreva\b', pergunta_normalizada) and not consulta_peca:
        return None
    if re.search(r'confirme|ignore|nao esqueca|\b(certo|correto|cocar|cabelo|olhos|frase|palavras)\b', pergunta_normalizada):
        return None
    if not consulta_peca and re.search(r'\broupas?\b', pergunta_normalizada):
        return None
    titulo = re.search(r'^\*\*Obra \d+: (.+?)\*\*', obra).group(1)
    detalhes = re.search(r'^\* \*\*Detalhes visuais:\*\* (.+)$', obra, re.MULTILINE)
    if detalhes is None:
        return None
    partes = []
    geral = re.search(r'^\* \*\*Informações gerais sobre a obra:\*\* (.+)$', obra, re.MULTILINE)
    if geral and 'objetos' not in pergunta_normalizada:
        partes.append(geral.group(1).strip())
    partes.append(detalhes.group(1).strip())
    return f'Descrição cadastrada de "{titulo}":\n\n' + '\n\n'.join(partes)

