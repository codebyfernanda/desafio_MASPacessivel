# Estudo: nomes claros, responsabilidades explícitas e comentários sobre decisões.
# Condições de visitação vêm dos campos da fonte. Preservar condições
# de gratuidade e agendamento evita prometer benefícios por inferência.

"""Consulta de horários diretamente nos campos recuperados da base."""
import re
from .rag import normalizar


def responder_horario(pergunta, documentos):
    pergunta = normalizar(pergunta)
    if not re.search(r'\b(abre|aberto|aberta|fecha|fechado|fechada|funciona|funcionamento|horarios?)\b|ate que horas', pergunta):
        return None
    dias = {
        'segunda': 'segundas-feiras', 'terca': 'terças-feiras',
        'quarta': 'quartas-feiras', 'quinta': 'quintas-feiras',
        'sexta': 'sextas-feiras', 'sabado': 'sábados', 'domingo': 'domingos',
    }
    citados = [dia for dia in dias if re.search(r'\b' + dia + r's?\b', pergunta)]
    if len(citados) != 1:
        return None
    dia = citados[0]
    for documento in documentos:
        campo = re.search(r'^\* \*\*Horários de Funcionamento:\*\* (.+)$', documento, re.MULTILINE)
        if campo is None:
            continue
        for trecho in campo.group(1).split(';'):
            grupo, separador, horario = trecho.partition(':')
            if not separador or not re.search(r'\b' + dia + r'\b', normalizar(grupo)):
                continue
            horario = horario.strip().rstrip('.')
            if not horario:
                return None
            preposicao = 'aos' if dia in ('sabado', 'domingo') else 'às'
            if normalizar(horario) == 'fechado':
                return f'O MASP está fechado {preposicao} {dias[dia]}.'
            return f'Horário do MASP {preposicao} {dias[dia]}: {horario}.'
    return None


def responder_acessibilidade(pergunta, documentos):
    pergunta = normalizar(pergunta)
    if re.search(r'\b(obra|quadro|pintura|escultura|tela)\b', pergunta):
        return None
    if not re.search(r'\b(rampas?|elevadores?)\b|piso tatil|acessibilidade fisica|estruturas?.{0,40}(acess|pessoas|cadeira)', pergunta):
        return None
    # Pedidos compostos envolvendo benefícios ou ingresso exigem tratar também
    # essas condições; listar infraestrutura não responde a essas perguntas.
    if re.search(r'almoco|cortesia|ingresso|entrada|gratuidade|\bgratis\b', pergunta):
        return None
    for documento in documentos:
        campo = re.search(r'^\* \*\*Acessibilidade Física no Local:\*\* (.+)$', documento, re.MULTILINE)
        if campo:
            return campo.group(1).strip()
    return None


def responder_gratuidade_pcd(pergunta, documentos):
    pergunta = normalizar(pergunta)
    publico = re.search(r'\bpcd\b|pessoas? com deficiencia|cadeiras? de rodas', pergunta)
    beneficio = re.search(r'gratuid|gratuit|\bgratis\b|de graca|cortesia|beneficio|almoco', pergunta)
    if not (publico and beneficio):
        return None
    for documento in documentos:
        regra = re.search(r'^\* \*\*Gratuidade para pessoas com deficiência:\*\* (.+)$', documento, re.MULTILINE)
        if regra is None:
            continue
        partes = [regra.group(1).strip()]
        geral = re.search(r'^\* \*\*Entrada gratuita para o público geral:\*\* (.+)$', documento, re.MULTILINE)
        if geral:
            partes.append('Gratuidade para o público geral: ' + geral.group(1).strip())
        horarios = re.search(r'^\* \*\*Horários de Funcionamento:\*\* (.+)$', documento, re.MULTILINE)
        if horarios:
            if re.search(r'horarios?|\bhoras?\b', pergunta):
                partes.append('Horários de funcionamento: ' + horarios.group(1).strip())
            else:
                fechados = [trecho_horario.strip() for trecho_horario in horarios.group(1).split(';') if 'fechado' in normalizar(trecho_horario)]
                if fechados:
                    partes.append('Dias sem funcionamento: ' + '; '.join(fechados))
        infraestrutura = re.search(r'^\* \*\*Acessibilidade Física no Local:\*\* (.+)$', documento, re.MULTILINE)
        if infraestrutura:
            emprestimo = re.search(r'cadeiras de rodas[^.]*empréstimo[^.]*', infraestrutura.group(1))
            if emprestimo:
                partes.append(emprestimo.group(0)[0].upper() + emprestimo.group(0)[1:] + '.')
        return '\n\n'.join(partes)
    return None

