"""Responde consultas factuais por campos da fonte já validada pelo chatbot.

Não conhece o golden: títulos, cores, datas e condições vêm dos documentos.
Quando não há uma regra adequada, devolve None e mantém a geração existente.
"""
import re
from .rag import normalizar


def campos_documentados(documento):
    return dict(re.findall(r'^\* \*\*([^*]+):\*\* (.+)$', documento, re.MULTILINE))


def obras_documentadas(documentos):
    obras = []
    for documento in documentos:
        cabecalho = re.match(r'^\*\*Obra \d+: (.+?)\*\*', documento)
        if cabecalho:
            obras.append((cabecalho.group(1), campos_documentados(documento)))
    return obras


def descricao_da_fonte(titulo, campos, incluir_tecnica=False):
    partes = []
    if incluir_tecnica and campos.get('Técnica'):
        partes.append('Técnica: ' + campos['Técnica'])
    for nome in ('Informações gerais sobre a obra', 'Detalhes visuais'):
        if campos.get(nome):
            partes.append(campos[nome])
    if not partes:
        return None
    return f'"{titulo}":\n\n' + '\n\n'.join(dict.fromkeys(partes))


def responder_consulta_documentada(pergunta, documentos):
    consulta = normalizar(pergunta)
    obras = obras_documentadas(documentos)
    if not obras:
        if re.search(r'programacao cultural|agenda cultural|eventos (do|no) masp', consulta):
            programacao = [valor for documento in documentos for nome, valor in campos_documentados(documento).items()
                           if re.search(r'programacao|agenda|eventos', normalizar(nome))]
            if programacao:
                return '\n\n'.join(dict.fromkeys(programacao))
            # A lacuna de agenda não deve ser preenchida com eventos ou URLs inventados.
            return ('Não encontrei a programação cultural atual na base consultada. '
                    'Consulte os canais oficiais do MASP para informações atualizadas.')
        for documento in documentos:
            campos = campos_documentados(documento)
            if (re.search(r'entrada|ingresso|visita', consulta)
                    and re.search(r'gratuit|gratuid|de graca|\bgratis\b', consulta)
                    and not re.search(r'\bpcd\b|deficiencia|cadeira|almoco|transporte|beneficio', consulta)
                    and campos.get('Entrada gratuita para o público geral')):
                return 'Entrada gratuita para o público geral: ' + campos['Entrada gratuita para o público geral']
        return None

    if len(obras) > 1:
        if not re.search(r'compar|diferenc|semelhanc|outra obra', consulta):
            return None
        # Comparar cenas documentadas não autoriza inventar doadores ou intenções.
        descricoes = [descricao_da_fonte(titulo, campos, incluir_tecnica=True) for titulo, campos in obras]
        if not all(descricoes):
            return None
        return 'Comparação pelas descrições disponíveis:\n\n' + '\n\n'.join(descricoes)

    titulo, campos = obras[0]
    if re.search(r'contexto historico|historia (da|dessa|desta)|contexto (dela|dele|da obra)', consulta):
        contextos = [valor for nome, valor in campos.items() if normalizar(nome).startswith('contexto')]
        if contextos:
            return '\n\n'.join(contextos)
        return f'Não encontrei contexto histórico documentado para "{titulo}" nas fontes consultadas.'

    confirmacao = re.search(r'\b(confirme|confirmar|correto|certo)\b|nao (tem|esqueca)|\bok\?', consulta)
    if confirmacao:
        descricao = descricao_da_fonte(titulo, campos, incluir_tecnica=True)
        if not descricao:
            return None
        # A fonte corrige a premissa pelo que afirma, sem transformar silêncio em ausência.
        observacao = campos.get('Observação visual da reprodução oficial')
        if observacao:
            observacao = observacao.split('Verificação visual', 1)[0].strip()
            descricao += '\n\n' + observacao
        return 'Para conferir a afirmação, a fonte registra:\n\n' + descricao

    pedido_geral = re.search(r'^(fale|me conte|conte-me) sobre\b|gostaria de (saber|informacoes) sobre', consulta)
    if pedido_geral and not re.search(r'\b(politic|opinia|simbol|signific|nascimento|nasceu)\w*', consulta):
        return descricao_da_fonte(titulo, campos, incluir_tecnica=True)
    return None
