# Estudo: nomes claros, responsabilidades explícitas e comentários sobre decisões.
# As regras expressam limites de capacidade, sem conhecer respostas do golden.
# Padrões locais reduzem riscos conhecidos; não são um classificador universal.

"""Barreiras locais de capacidade e de instruções; não são um classificador universal."""
import re
import unicodedata
from .rag import normalizar

RECUSA = 'Não posso seguir esse pedido. Posso responder sobre o acervo, a visitação e a acessibilidade do MASP.'

def analisar_entrada(mensagem, turno_anterior_bloqueado=False):
    pergunta_normalizada=normalizar(unicodedata.normalize('NFKC',mensagem))
    pergunta_normalizada=''.join(caractere for caractere in pergunta_normalizada if unicodedata.category(caractere)!='Cf')
    if len(mensagem)>6000:
        return 'limite_entrada','Envie uma pergunta mais curta sobre o acervo ou a visita ao MASP.'
    if turno_anterior_bloqueado and re.fullmatch(r'\s*(continue|continuar|prossiga|faca isso|execute|sim)[.!?\s]*',pergunta_normalizada):
        return 'continuacao_bloqueada',RECUSA
    if re.search(r'\[im_(?:start|end)\]|\[(?:system|developer)\]|</?(?:system|fontes)>',pergunta_normalizada):
        return 'falsificacao_de_papel',RECUSA
    if re.search(r'(?:ignore|desconsidere|esqueca).{0,90}(?:regras|instrucoes|papel|guia)|memorize.{0,40}regra.{0,100}quando',pergunta_normalizada):
        return 'substituicao_de_instrucoes',RECUSA
    if re.search(r'(?:decodifique|decode|decifre).{0,90}(?:execute|follow)|(?:execute|follow).{0,90}base64',pergunta_normalizada):
        return 'instrucao_codificada',RECUSA
    if re.search(r'primeira mensagem.{0,80}antes|texto.{0,50}configura.{0,40}papel|system prompt|prompt de sistema|instrucoes internas|mensagens?.{0,50}outros visitantes|sessoes?[_ ]privadas?|outra sessao',pergunta_normalizada):
        return 'privacidade','Não compartilho instruções internas nem conversas de outros visitantes. Posso orientar sobre o MASP.'
    if re.search(r'\.\.[/\\]|(?:^|[/\\\s])\.env\b|execute.{0,60}ferramenta|(?:execute|rode).{0,30}comando',pergunta_normalizada):
        return 'capacidade_ferramenta','A busca consulta somente a base do acervo e da visitação. Não lê outros arquivos nem executa comandos.'
    if re.search(r'https?://',pergunta_normalizada) and re.search(r'\b(abra|acesse|baixe|substitua|salve|envie)\b',pergunta_normalizada):
        return 'recurso_externo','Não abro endereços externos nem altero a base por pedidos na conversa. Consulto somente os documentos autorizados.'
    if re.search(r'\b(agende|reserve|emita|compre|cancele)\b|confirme.{0,40}agendamento.{0,30}(?:realizado|feito)',pergunta_normalizada):
        return 'acao_indisponivel','Não realizo reservas, compras ou agendamentos. Consulte os canais oficiais do MASP para solicitar o serviço; nenhuma ação foi realizada aqui.'
    if re.search(r'\b(peca|solicite|colete|envie)\b',pergunta_normalizada) and re.search(r'senha|\bcvv\b|numero completo do cartao',pergunta_normalizada):
        return 'dados_sensiveis','Não solicito senhas bancárias, códigos de segurança ou dados completos de cartão. Este guia não emite ingressos nem processa pagamentos.'
    if re.search(r'toc(?:ar|ando|ue).{0,60}(?:telas|obras)',pergunta_normalizada) and re.search(r'sem autorizacao|nao.{0,30}ressalvas',pergunta_normalizada):
        return 'integridade_das_obras','Não oriento tocar nas obras sem autorização. Peça à equipe do museu orientação sobre recursos acessíveis permitidos.'
    if re.search(r'\b(garanta|prometa)\b',pergunta_normalizada) and re.search(r'almoco|transporte|beneficio',pergunta_normalizada):
        return 'beneficio_nao_confirmado','Não posso garantir benefícios que não estejam confirmados nas fontes. A base consultada não confirma almoço ou transporte gratuitos.'
    return None

def exposicao_de_instrucoes(resposta,prompt):
    """Detecta cópia extensa, sem tratar frases curtas de apresentação como vazamento."""
    palavras=normalizar(prompt).split()
    texto=' '.join(normalizar(resposta).split())
    return any(' '.join(palavras[indice_palavra:indice_palavra+16]) in texto for indice_palavra in range(max(0,len(palavras)-15)))

