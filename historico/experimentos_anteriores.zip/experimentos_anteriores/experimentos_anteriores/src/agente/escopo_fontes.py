# Estudo: nomes claros, responsabilidades explícitas e comentários sobre decisões.
# Informações gerais do museu não sustentam a descrição de uma obra.
# A ausência de fonte deve ficar visível, em vez de virar uma resposta inventada.

"""Evita descrições de obras quando a recuperação não encontrou sua referência."""
import re
from .rag import normalizar


def responder_obra_sem_fonte(pergunta, documentos):
    if any(re.match(r'^\*\*Obra \d+:', documento_consultado) for documento_consultado in documentos):
        return None
    pergunta_normalizada = normalizar(pergunta)
    # Informações gerais do museu não sustentam descrições de uma obra.
    pedido_obra = re.search(r'\b(obra|pintura|tela|escultura|quadro|retrato)\b', pergunta_normalizada)
    pedido_descricao = re.search(r'\b(descreva|descrever|descricao|detalhes|cores)\b|como e\b|fale sobre|conte sobre', pergunta_normalizada)
    if not (pedido_obra and pedido_descricao):
        return None
    return ('Não encontrei uma referência para essa obra na base disponível do MASP. '
            'Não posso descrevê-la sem uma fonte. Meu atendimento se limita ao acervo '
            'e à visitação do MASP; confirme o título ou o nome do artista para a busca.')

