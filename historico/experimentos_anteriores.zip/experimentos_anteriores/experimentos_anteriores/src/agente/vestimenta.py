# Estudo: nomes claros, responsabilidades explícitas e comentários sobre decisões.
# A seleção considera a pessoa citada para não atribuir a ela roupas
# de personagens presentes em quadros secundários da mesma imagem.

"""Extrai da descrição as roupas, adornos e cobertura corporal solicitados."""
import re
from .rag import normalizar


def responder_vestimenta(pergunta, documentos):
    pergunta_normalizada = normalizar(pergunta)
    if not re.search(r'\bo que\b.{0,80}\b(vestindo|veste|vestem)\b', pergunta_normalizada):
        return None
    if re.search(r'confirme|ignore|\b(certo|correto|quem|quando|tecnica|ano|autor|autora)\b|nao (e|esta)|\?', pergunta_normalizada.rstrip('?')):
        return None
    alvo = re.search(r'\b(homem|mulher|figura|pessoa)\b', pergunta_normalizada)
    if alvo is None:
        return None
    obras = [documento for documento in documentos if re.match(r'^\*\*Obra \d+:', documento)]
    if len(obras) != 1:
        return None
    introducao = ''
    alvo_nome = alvo.group(1)
    geral = re.search(r'^\* \*\*Informações gerais sobre a obra:\*\* (.+)$', obras[0], re.MULTILINE)
    if geral and alvo_nome in ('homem', 'mulher'):
        outro = 'mulher' if alvo_nome == 'homem' else 'homem'
        geral_normalizado = normalizar(geral[1])
        if (not re.search(r'\b' + alvo_nome + r'\b', geral_normalizado)
                and re.search(r'\b' + outro + r'\b', geral_normalizado)
                and not re.search(r'ao fundo|quadro menor|cena secundaria', pergunta_normalizada)):
            # Corrigir o referente não autoriza concluir que a pessoa pedida está nua.
            artigo = 'uma' if outro == 'mulher' else 'um'
            introducao = f'A figura identificada na descrição principal é {artigo} {outro}. '
            alvo_nome = outro
    campos = re.findall(r'^\* \*\*(?:Informações gerais sobre a obra|Detalhes visuais):\*\* (.+)$',
                        obras[0], re.MULTILINE)
    trechos = [trecho_fonte.strip() for campo in campos for trecho_fonte in re.split(r'(?<=[.!?])\s+', campo)]
    roupas = r'\b(veste|vestem|vestindo|vestid[oa]s?|roupas?|camisetas?|camisas?|calcas?|lencos?|aderecos?|adornos?|botas?|sapatos?|saia|blusas?)\b'
    cobertura = r'\bcorpo\b.{0,80}\b(cobert[oa]|pintad[oa])\b'
    selecionados = []
    for trecho in trechos:
        texto = normalizar(trecho)
        sujeito_citado = re.search(r'\b' + alvo_nome + r'\b', texto)
        continuacao = re.match(r'^(ele|ela)\b|^(seu|sua) (corpo|pele|roupa|vestido|camisa|blusa)\b', texto)
        if (sujeito_citado or continuacao) and (re.search(roupas, texto) or re.search(cobertura, texto)):
            # Uma frase pode misturar rosto e cobertura corporal. Preserve a cobertura
            # pedida sem acrescentar a oração sobre o rosto à resposta de vestimenta.
            composto = re.match(r'^(Seu corpo) não tem rosto[^.]+? e (é .+)$', trecho, re.I)
            if composto and re.search(cobertura, normalizar(composto[1] + ' ' + composto[2])):
                trecho = composto[1] + ' ' + composto[2]
            selecionados.append(trecho)
    # Sem texto pertinente, deixa o modelo tratar a lacuna com as fontes disponíveis.
    return introducao + ' '.join(dict.fromkeys(selecionados)) if selecionados else None

