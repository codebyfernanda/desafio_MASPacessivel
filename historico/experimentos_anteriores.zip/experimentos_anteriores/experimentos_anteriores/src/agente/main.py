# Estudo: nomes claros, responsabilidades explícitas e comentários sobre decisões.
# A interface do terminal cuida de entrada e saída; as regras do domínio
# ficam no chatbot e nos extratores, permitindo testá-las sem interação manual.

import sys
from pathlib import Path
from src.agente.chatbot import MASPChatbot

def iniciar_loop_chat(bot: MASPChatbot) -> None:
    """Gerencia o ciclo de vida da conversa no terminal."""
    print("Iniciando o MASP Guia Acessível (CLI)...")
    print("Digite 'sair' para encerrar a conversa.\n")
    
    while True:
        try:
            mensagem_visitante = input("Você: ")
            
            if mensagem_visitante.strip().lower() in ['sair', 'exit', 'quit']:
                print("Encerrando conversa de forma graciosa...")
                break
            
            if not mensagem_visitante.strip():
                continue
            
            resposta_servico = bot.get_response(mensagem_visitante)
            print(f"\nGuia MASP: {resposta_servico}\n")
            
        except KeyboardInterrupt:
            # Captura CTRL+C para não estourar uma exceção de erro no terminal do usuário
            print("\nEncerrando conversa abruptamente...")
            break

def main() -> None:
    # Garante que o caminho do prompt será resolvido corretamente, independente de onde o script for chamado
    diretorio_atual = Path(__file__).parent
    caminho_prompt = diretorio_atual / "prompt_de_sistema_inicial.md"
    
    guia_masp = MASPChatbot(prompt_path=str(caminho_prompt))
    iniciar_loop_chat(guia_masp)

if __name__ == "__main__":
    main()
