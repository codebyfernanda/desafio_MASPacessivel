# Estudo: nomes claros, responsabilidades explícitas e comentários sobre decisões.
# A fonte é uma fronteira de confiança. A integridade é verificada antes de
# copiar descrições literalmente ou encaminhar documentos ao modelo.

"""Busca local por títulos, artistas e contexto da sessão; sem acesso ao golden."""
import re
import unicodedata
import hashlib
import json
from pathlib import Path

def normalizar(texto):
    return "".join(caractere for caractere in unicodedata.normalize("NFD", texto.casefold()) if unicodedata.category(caractere) != "Mn")

class BaseConhecimento:
    def __init__(self, path=None):
        padrao = path is None
        path = Path(path) if path else Path(__file__).resolve().parents[2] / "dados/base_conhecimento_rag.md"
        # Um caminho alternativo é configuração do chamador, usada também pelos testes.
        # A mensagem do visitante nunca escolhe o arquivo carregado pelo construtor.
        if padrao:
            manifesto = json.loads(path.with_name('base_conhecimento_manifesto.json').read_text(encoding='utf-8'))
            if hashlib.sha256(path.read_bytes()).hexdigest() != manifesto['sha256']:
                raise ValueError('A base difere da versão revisada. É necessária revisão administrativa antes de publicá-la.')
        partes = re.split(r"(?=\*\*Obra \d+:)", path.read_text(encoding="utf-8"))
        self.geral = partes[0]
        self.obras = partes[1:]
        self._documentos_confiaveis = frozenset(partes)

    def validar_documentos(self, documentos):
        return (isinstance(documentos, list) and 0 < len(documentos) <= 10
                and all(isinstance(documento,str) and documento in self._documentos_confiaveis for documento in documentos)
                and sum(len(documento) for documento in documentos) <= 60000)

    def buscar(self, pergunta, anteriores=()):
        pergunta_normalizada = normalizar(pergunta)
        selecionadas = []
        for obra in self.obras:
            titulo = normalizar(obra.split("**", 2)[1].split(":", 1)[1].strip())
            artista = re.search(r"\*\*Artista:\*\* (.+)", obra).group(1).rstrip(".")
            nomes_alternativos = [titulo, titulo.rstrip('?!'), titulo.split(" [")[0], normalizar(artista)]
            if any(re.search(r"(?<!\w)" + re.escape(nome_alternativo) + r"(?!\w)", pergunta_normalizada) for nome_alternativo in nomes_alternativos) or ("profecias" in pergunta_normalizada and "profecias" in titulo):
                selecionadas.append(obra)
        if not selecionadas and re.search(r"\b(dela|dele|nela|nele|mulher|figura|mesma artista|outra obra|comparar)\b", pergunta_normalizada):
            selecionadas = [documento_anterior for documento_anterior in anteriores if documento_anterior in self.obras]
        if re.search(r"mesma artista|comparar|outra obra", pergunta_normalizada):
            for anterior in list(selecionadas):
                artista = re.search(r"\*\*Artista:\*\* (.+)", anterior).group(1)
                selecionadas.extend(outra_obra for outra_obra in self.obras if f"**Artista:** {artista}" in outra_obra and outra_obra not in selecionadas)
        return selecionadas or [self.geral]

