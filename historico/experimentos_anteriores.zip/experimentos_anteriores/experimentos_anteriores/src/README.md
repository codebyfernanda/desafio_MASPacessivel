# Mapa do código — o que manter e onde estudar

Comece por `agente/main.py`, depois `agente/chatbot.py` e `tests/test_integracao.py` na raiz. O chatbot organiza busca, resposta e proteção em funções menores.

| Local | Por que existe |
|---|---|
| `agente/chatbot.py` e `main.py` | Conversa e coordenação do agente local |
| `agente/rag.py` e `seguranca.py` | Recuperação, integridade das fontes e proteções |
| `agente/descricao.py`, `vestimenta.py`, `visitacao.py`, `escopo_fontes.py`, `respostas_documentadas.py` | Preservam detalhes e condições das fontes; o chatbot importa esses arquivos |
| `agente/prompt_de_sistema_inicial.md` | Instruções usadas pelo agente local |
| `deepeval/juiz.py` | Modelo-juiz, parâmetros e três métricas |
| `deepeval/casos.py` e `dataset.py` | Preparam casos e conversas sem enviar o esperado ao agente |
| `deepeval/extracao.py`, `fidelidade.py`, `templates.py` | Apoiam o julgamento sem perder informações da fonte |
| `agent_core/` | Scripts e configuração da AWS; veja o [procedimento](agent_core/README.md) |
| `executar_campanha.py` | Captura ataques e controles; não classifica resistência automaticamente |

Os módulos de agente e DeepEval são necessários ao fluxo atual. Na AWS, os scripts têm etapas distintas: captura, exportação de spans, registro do customizado e avaliação. `politica_inspecao_harness.json` é apoio para revisão de permissões pelo responsável pela conta; não é aplicado automaticamente. O prompt candidato e `config.json` documentam a configuração preparada.

Não é preciso apagar módulos para simplificar o estudo: eles ficam agrupados por função. `resultados/frente_b/entrega_resumida/` guarda evidência antiga; não é dependência de execução. `DEMO_6_MINUTOS.md` serve à apresentação. O manifesto da base, por sua vez, é lido pelo agente.

Use os [comandos da raiz](../README.md). Depois de uma mudança, rode os 45 testes; para medir qualidade, rode o golden separadamente. Testes de código aprovados não substituem notas dos modelos ou evidências AWS.
