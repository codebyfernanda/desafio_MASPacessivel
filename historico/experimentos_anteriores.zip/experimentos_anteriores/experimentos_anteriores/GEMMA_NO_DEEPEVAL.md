# Gemma do AgentCore avaliado também pelo DeepEval

Este complemento acrescenta uma avaliação das respostas reais do Gemma já capturadas na AWS. Os resultados anteriores do Qwen continuam válidos como histórico separado. O juiz continua sendo o DeepSeek R1 local, com temperatura 0,2. Gemma é o agente avaliado, DeepEval é a biblioteca de avaliação e DeepSeek é o modelo que atribui notas.

## Instalação

Extraia o ZIP do complemento. Copie `avaliar_gemma.py`, `test_gemma_capturas.py` e este guia para a pasta principal `MASP - Projeto organizado`, ao lado de `executar.py`, `dados` e `src`. Não execute dentro do ZIP. O complemento depende dos módulos `src/deepeval` do projeto revisado.

Abra o terminal nessa pasta. Execute um comando por vez:

```powershell
.\.venv\Scripts\python.exe -m pip install "deepeval==4.2.3" "ollama==0.6.2" "pytest==9.1.1" "httpx==0.28.1"
```

Abra o aplicativo Ollama e confira:

```powershell
ollama list
```

Deve aparecer `deepseek-r1:latest`, o juiz usado no projeto. Se não aparecer, pare e confira o ambiente antes da avaliação. Não é necessário baixar nem executar Qwen para avaliar estas capturas. O programa registra o digest do juiz instalado e impede retomar uma rodada se esse modelo tiver mudado. Variáveis `MASP_JUDGE_MODEL`, `MASP_FAITHFULNESS_MODEL` e `MASP_CONFORMITY_MODEL`, se definidas, continuam sendo respeitadas e registradas.

## Conferir os arquivos, sem executar avaliações

```powershell
.\.venv\Scripts\python.exe avaliar_gemma.py baseline --validar
```

```powershell
.\.venv\Scripts\python.exe avaliar_gemma.py final --validar
```

Cada comando deve informar `35 casos validados`. As entradas são `resultados/frente_a/golden_baseline_com_spans.json` e `resultados/frente_a/golden_final_rag_seletivo.json`. Não substitua por capturas de Qwen ou pela primeira rodada final com RAG integral.

## Executar

Primeiro o baseline:

```powershell
.\.venv\Scripts\python.exe avaliar_gemma.py baseline
```

Depois que a rodada terminar, execute a versão final:

```powershell
.\.venv\Scripts\python.exe avaliar_gemma.py final
```

O comando usa Pytest para executar métricas reais do DeepEval, sequencialmente. O tempo depende do computador e do juiz; cada métrica pode fazer várias chamadas ao modelo. Não há nova chamada ao agente nem alteração na AWS.

## Resultados e interrupções

Os resultados ficam separados em `resultados/frente_b/gemma/baseline.json` e `final.json`. Cada arquivo contém notas, erros, justificativas disponíveis, médias e quantidades avaliadas. Os arquivos `.jsonl` guardam cada métrica assim que ela termina; também são texto legível no VS Code. Preserve-os: são as evidências e permitem retomar.

Se a execução for interrompida antes de gerar o JSON final, repita o comando acrescentando `--retomar`, por exemplo:

```powershell
.\.venv\Scripts\python.exe avaliar_gemma.py final --retomar
```

Notas baixas e erros já gravados não são repetidos. Uma chamada interrompida antes da gravação pode precisar ser refeita. Se um JSONL estiver truncado, o programa interrompe com erro; não apague os registros para aumentar a aprovação. Rode somente uma avaliação por vez.

`FAILED` pode significar nota abaixo do limite ou erro técnico do juiz: consulte `status` e `erro` no registro para diferenciar. `SKIPPED` no baseline indica avaliação parcial sem evidência para Faithfulness, desde que as outras métricas não tenham reprovado. Nenhum desses estados comprova aprovação integral.

## Como interpretar a comparação

| Métrica | Baseline Gemma | Final Gemma |
|---|---|---|
| Answer Relevancy, mínimo 0,7 | Última resposta de cada um dos 35 casos | Mesmo procedimento |
| Faithfulness, mínimo 0,8 | Não avaliável: falta contexto RAG registrado | Documentos reais recuperados e disponíveis na sessão |
| G-Eval, mínimo 0,8 | Conversa e critério esperado; verificação factual limitada sem fontes | Conversa, critério esperado e documentos registrados |

O programa não preenche o contexto ausente do baseline com a base revisada. A documentação de [Faithfulness](https://deepeval.com/docs/metrics-faithfulness) define a métrica em relação ao contexto recuperado. Ausência de evidência fica explícita, sem nota zero nem aprovação artificial. O G-Eval do baseline também exige interpretação cuidadosa: o critério esperado não substitui uma fonte factual completa.

O baseline não terá três notas comparáveis por caso. Esta limitação histórica permanece no relatório; adicionar o adaptador não a resolve. A versão final permite executar as três métricas sobre o mesmo agente avaliado na frente A. Só resultados reais concluídos comprovam essa nova execução.

Os casos com mais de um turno continuam inteiros: relevância e fidelidade avaliam a última resposta; G-Eval considera a conversa. As médias existentes na AWS incluem até 42 respostas, enquanto este protocolo usa 35 casos; não compare diretamente percentuais como se os denominadores fossem idênticos.

O RAG final foi chamado pela aplicação antes do harness. Notas altas não demonstram que o Gemma chamou a ferramenta autonomamente. O requisito de uso correto da ferramenta precisa continuar sendo conferido nas evidências da frente A.

Ao encerrar as duas rodadas, compare: quais casos cada frente detectou, falsos positivos/negativos do juiz, diferenças de contexto e cobertura, erros técnicos e limites de cada métrica. Preserve o Qwen como estudo adicional. Este complemento trata o golden de 35 casos; a campanha de red teaming de 15 tentativas mantém seus registros anteriores.

## Verificação do complemento

Em 24/09/2026, as duas capturas reais passaram na validação offline; 8 verificações do adaptador passaram, incluindo contexto adulterado, retomada, log truncado e erro do juiz. Os 45 testes existentes passaram. Os 35 testes de avaliação ficaram desativados nessa verificação para não iniciar uma campanha com o modelo. As três métricas foram instanciadas com DeepEval 4.2.3 e o juiz configurado.

Atualização após a execução da autora: o baseline real Gemma foi concluído e está em resultados/frente_b/gemma/baseline.json: 27/35 aprovações em Answer Relevancy, 9/35 em G-Eval e 35 registros não avaliáveis em Faithfulness. O final também foi concluído: relevância 17/35, Faithfulness 32/35, G-Eval 18/35 e aprovação conjunta 9/35. Nenhum erro técnico ficou pendente. A comparação está em resultados/frente_b/gemma/comparacao_golden.json. A campanha DeepEval dos 15 ataques também foi concluída: baseline/final salvos, AR 6/15 → 6/15, G-Eval 5/15 → 8/15, Faithfulness não avaliável → 15/15. Veja REDTEAM_GEMMA_NO_DEEPEVAL.md e resultados/frente_b/gemma/comparacao_redteam.json. Os testes offline citados acima usam simulações apenas para verificar o código e não substituem essas evidências reais.
