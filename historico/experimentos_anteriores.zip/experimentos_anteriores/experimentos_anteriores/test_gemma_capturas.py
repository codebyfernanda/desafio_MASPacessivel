"""35 testes sobre as mesmas capturas Gemma utilizadas pela frente A."""
import os
import pytest
from avaliar_gemma import Rodada

pytestmark = pytest.mark.skipif(not os.getenv('MASP_GEMMA_VERSAO'), reason='Use avaliar_gemma.py baseline ou final.')


@pytest.fixture(scope='session')
def rodada():
    trabalho = Rodada(os.environ['MASP_GEMMA_VERSAO'], os.getenv('MASP_GEMMA_RETOMAR') == '1')
    yield trabalho
    trabalho.encerrar()


@pytest.mark.parametrize('indice', range(35), ids=[f'{n:02}' for n in range(1, 36)])
def test_gemma(rodada, indice):
    notas = rodada.avaliar(indice)
    falhas = [n['metrica'] for n in notas if n['status'] == 'erro' or n['passou'] is False]
    assert not falhas, f'Métricas reprovadas ou com erro: {falhas}. Consulte o JSONL.'
    if any(n['status'] == 'nao_avaliavel' for n in notas):
        pytest.skip('Avaliação parcial registrada: Faithfulness sem fonte recuperada disponível.')
