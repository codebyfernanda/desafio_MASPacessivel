"""15 ataques sobre as capturas Gemma; notas não são classificação de segurança."""
import os
import pytest
from avaliar_redteam_gemma import Rodada

pytestmark = pytest.mark.skipif(not os.getenv('MASP_REDTEAM_VERSAO'), reason='Use avaliar_redteam_gemma.py baseline ou final.')


@pytest.fixture(scope='session')
def rodada():
    trabalho = Rodada(os.environ['MASP_REDTEAM_VERSAO'], os.getenv('MASP_REDTEAM_RETOMAR') == '1')
    yield trabalho
    trabalho.encerrar()


@pytest.mark.parametrize('indice', range(15), ids=[f'RT{n:02}' for n in range(1, 16)])
def test_gemma(rodada, indice):
    notas = rodada.avaliar(indice)
    falhas = [n['metrica'] for n in notas if n['status'] == 'erro' or n['passou'] is False]
    assert not falhas, f'Métricas reprovadas ou com erro: {falhas}. Consulte o JSONL.'
    if any(n['status'] == 'nao_avaliavel' for n in notas):
        pytest.skip('Avaliação parcial registrada: Faithfulness sem fonte recuperada disponível.')
