"""Avalia respostas AWS já salvas. Não chama a AWS nem gera novas respostas."""
import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import subprocess
import sys

RAIZ = Path(__file__).resolve().parent
CAPTURAS = {
    'baseline': 'golden_baseline_com_spans.json',
    'final': 'golden_final_rag_seletivo.json',
}
NOMES = ('Answer Relevancy', 'Faithfulness', 'G-Eval')
MODELOS = ('MASP_JUDGE_MODEL', 'MASP_FAITHFULNESS_MODEL', 'MASP_CONFORMITY_MODEL')


def sha(arquivo):
    return hashlib.sha256(arquivo.read_bytes()).hexdigest()


def ler(arquivo):
    return json.loads(arquivo.read_text(encoding='utf-8-sig'))


def carregar(versao):
    """Falha antes da avaliação se a captura estiver incompleta ou adulterada."""
    origem = RAIZ / 'resultados/frente_a' / CAPTURAS[versao]
    golden_path = RAIZ / 'dados/golden_dataset.json'
    captura, golden = ler(origem), ler(golden_path)
    meta = captura['metadata']
    if meta['status'] != 'finalizado' or meta['versao'] != versao:
        raise ValueError('A captura não está finalizada na versão solicitada.')
    if len(golden) != 35 or meta['dataset_sha256'] != sha(golden_path):
        raise ValueError('O golden deve ter os mesmos 35 casos da captura.')
    registros = captura['resultados']
    if [r['caso_id'] for r in registros] != [c['id'] for c in golden]:
        raise ValueError('IDs ou ordem da captura diferentes do golden.')
    if len({r['session_id'] for r in registros}) != 35:
        raise ValueError('Sessões repetidas ou ausentes.')
    for r in registros:
        if r.get('erro') or not r['turnos'] or len(r['turnos']) != len(r['respostas']):
            raise ValueError(f"Captura incompleta: {r['caso_id']}")
        if not all(isinstance(t, str) and t.strip() for t in r['turnos'] + r['respostas']):
            raise ValueError('Pergunta ou resposta vazia.')
        recuperacoes = r.get('recuperacoes_por_turno', [])
        if versao == 'final' and len(recuperacoes) != len(r['turnos']):
            raise ValueError('Falta recuperação por turno na captura final.')
        for pergunta, rec in zip(r['turnos'], recuperacoes):
            if rec['session_id'] != r['session_id'] or rec['pergunta'] != pergunta or rec['status'] != 'recuperado':
                raise ValueError('Contexto de outra sessão/turno ou recuperação sem sucesso.')
            docs = rec['documentos_recuperados']
            if not docs or rec['base_sha256'] != meta['base_local_sha256']:
                raise ValueError('Recuperação sem documentos ou base divergente.')
            for doc in docs:
                digest = hashlib.sha256(doc['conteudo'].encode('utf-8')).hexdigest()
                if digest != doc['trecho_sha256'] or doc['base_sha256'] != rec['base_sha256']:
                    raise ValueError('Hash do trecho recuperado inválido.')
    return origem, captura, golden


def contextos(registro):
    """Cada evidência usa somente documentos realmente disponíveis na sessão."""
    recs = registro.get('recuperacoes_por_turno', [])
    todos = list(dict.fromkeys(d['conteudo'] for rec in recs for d in rec['documentos_recuperados']))
    # O harness conserva os turnos anteriores: estes documentos já estavam disponíveis.
    return todos


def assinatura(versao, origem):
    return {
        'protocolo': 'gemma_capturado_v1', 'versao': versao,
        'captura_sha256': sha(origem), 'dataset_sha256': sha(RAIZ / 'dados/golden_dataset.json'),
        'juizes': [os.getenv(k, 'deepseek-r1:latest') for k in MODELOS],
        'digests_juizes': juizes_instalados(),
        'temperatura_juiz': 0.2, 'thresholds': [0.7, 0.8, 0.8],
        'codigo_sha256': {str(p.relative_to(RAIZ)): sha(p) for p in
                          [RAIZ / 'avaliar_gemma.py', RAIZ / 'test_gemma_capturas.py']
                          + sorted((RAIZ / 'src/deepeval').glob('*.py'))},
        'bibliotecas': {n: importlib.metadata.version(n) for n in ('deepeval', 'ollama', 'pytest')},
    }


def juizes_instalados():
    """Registra o modelo real: o mesmo nome 'latest' pode mudar com um download."""
    from ollama import Client
    disponiveis = {m.model: m.digest for m in Client(timeout=10).list().models}
    escolhidos = {os.getenv(k, 'deepseek-r1:latest') for k in MODELOS}
    ausentes = escolhidos - disponiveis.keys()
    if ausentes:
        raise ValueError(f'Juiz ausente no Ollama: {sorted(ausentes)}. Confira ollama list.')
    return {nome: disponiveis[nome] for nome in sorted(escolhidos)}


def acrescentar(arquivo, valor):
    """Acrescenta um registro sem substituir arquivos abertos pelo OneDrive."""
    with arquivo.open('a', encoding='utf-8', newline='\n') as destino:
        destino.write(json.dumps(valor, ensure_ascii=False, allow_nan=False) + '\n')
        destino.flush()
        os.fsync(destino.fileno())


class Rodada:
    def __init__(self, versao, retomar=False):
        self.origem, self.captura, self.golden = carregar(versao)
        self.meta = assinatura(versao, self.origem)
        self.pasta = RAIZ / 'resultados/frente_b/gemma'
        self.pasta.mkdir(parents=True, exist_ok=True)
        self.log = self.pasta / f'{versao}.jsonl'
        self.saida = self.pasta / f'{versao}.json'
        self.notas = {}
        if self.saida.exists():
            raise ValueError(f'Rodada já encerrada: {self.saida}. Preserve o resultado.')
        if self.log.exists():
            if not retomar:
                raise ValueError('Já existe uma rodada parcial. Use --retomar.')
            linhas = [json.loads(l) for l in self.log.read_text(encoding='utf-8').splitlines()]
            if not linhas or linhas[0] != {'metadata': self.meta}:
                raise ValueError('Captura, código, juiz ou bibliotecas mudaram; retomada recusada.')
            permitidos = {(c['id'], nome) for c in self.golden for nome in NOMES}
            for nota in linhas[1:]:
                chave = (nota['caso_id'], nota['metrica'])
                if chave not in permitidos or chave in self.notas:
                    raise ValueError('Log com resultado duplicado ou desconhecido.')
                self.notas[chave] = nota
        else:
            # Criação exclusiva evita duas execuções iniciadas no mesmo arquivo.
            with self.log.open('x', encoding='utf-8') as destino:
                destino.write(json.dumps({'metadata': self.meta}, ensure_ascii=False) + '\n')

    def avaliar(self, indice):
        from src.deepeval.casos import montar_casos
        from src.deepeval.juiz import obter_metricas_base
        caso, registro = self.golden[indice], self.captura['resultados'][indice]
        contexto = contextos(registro)
        ultima, conversa = montar_casos(registro['turnos'], registro['respostas'], caso['expected_output'], contexto)
        for nome, metrica, evidencia in zip(NOMES, obter_metricas_base(), (ultima, ultima, conversa), strict=True):
            chave = (caso['id'], nome)
            if chave in self.notas:
                print(f'{caso["id"]}: {nome} já registrado; preservado.', flush=True)
                continue
            nota = {'caso_id': caso['id'], 'session_id': registro['session_id'], 'metrica': nome,
                    'threshold': metrica.threshold, 'score': None, 'passou': None,
                    'input_avaliado': evidencia.input, 'resposta_avaliada': evidencia.actual_output,
                    'retrieval_context': contexto}
            if nome == 'Faithfulness' and not contexto:
                nota.update(status='nao_avaliavel', razao='Baseline sem contexto recuperado registrado; não é zero nem aprovação.')
            else:
                print(f'{caso["id"]}/35: executando {nome}...', flush=True)
                try:
                    metrica.measure(evidencia)
                    if metrica.score is None or not math.isfinite(metrica.score):
                        raise ValueError('Juiz não produziu uma nota finita.')
                    nota.update(status='avaliado', score=metrica.score,
                                passou=bool(metrica.is_successful()), razao=metrica.reason)
                    for campo in ('statements', 'claims', 'verdicts'):
                        valores = getattr(metrica, campo, None)
                        if valores is not None:
                            nota[campo] = [v.model_dump() if hasattr(v, 'model_dump') else v for v in valores]
                except Exception as erro:
                    nota.update(status='erro', erro=f'{type(erro).__name__}: {erro}')
                nota['repeticoes_transporte'] = getattr(metrica.model, 'transport_retries', 0)
            # Falha ao gravar interrompe a rodada. Não repete chamadas para melhorar notas.
            acrescentar(self.log, nota)
            self.notas[chave] = nota
        return [self.notas[(caso['id'], n)] for n in NOMES]

    def encerrar(self):
        completo = len(self.notas) == 105
        if not completo:
            print(f'Rodada parcial: {len(self.notas)}/105 registros. Retome com --retomar.')
            return
        resumo = {}
        for nome in NOMES:
            notas = [n for n in self.notas.values() if n['metrica'] == nome]
            validas = [n for n in notas if n['status'] == 'avaliado']
            resumo[nome] = {'avaliados': len(validas), 'aprovados': sum(n['passou'] for n in validas),
                            'erros': sum(n['status'] == 'erro' for n in notas),
                            'nao_avaliaveis': sum(n['status'] == 'nao_avaliavel' for n in notas),
                            'media': sum(n['score'] for n in validas) / len(validas) if validas else None}
        dados = {'metadata': {**self.meta, 'status': 'finalizado', 'harness': self.captura['metadata'],
                             'limites': ['Faithfulness sem RAG registrado fica não avaliável.',
                                        'G-Eval do baseline tem suporte factual limitado pela ausência de fontes.',
                                        'AR/F avaliam a última resposta; G-Eval considera a conversa.',
                                        'Notas não comprovam uso autônomo da ferramenta nem aprovação integral do golden.',
                                        '35 casos no DeepEval; as médias AWS podem incluir 42 respostas.']},
                 'resumo': resumo, 'log_sha256': sha(self.log), 'resultados': list(self.notas.values())}
        with self.saida.open('x', encoding='utf-8') as destino:
            json.dump(dados, destino, ensure_ascii=False, indent=2, allow_nan=False)
        print(f'Resultado salvo: {self.saida}', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('versao', choices=CAPTURAS)
    parser.add_argument('--validar', action='store_true', help='Confere os arquivos sem chamar juiz ou AWS.')
    parser.add_argument('--retomar', action='store_true', help='Preserva todas as notas e erros já registrados.')
    args = parser.parse_args()
    carregar(args.versao)
    if args.validar:
        print(f'{args.versao}: 35 casos validados. Nenhuma avaliação executada.')
        return 0
    ambiente = dict(os.environ, MASP_GEMMA_VERSAO=args.versao,
                    MASP_GEMMA_RETOMAR='1' if args.retomar else '0',
                    DEEPEVAL_TELEMETRY_OPT_OUT='YES', PYTHONIOENCODING='utf-8')
    return subprocess.call([sys.executable, '-m', 'pytest', 'test_gemma_capturas.py', '-q', '-s',
                            '--tb=short', '-o', 'addopts='], cwd=RAIZ, env=ambiente)


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError) as erro:
        sys.exit(f'Não foi possível continuar: {erro}')
