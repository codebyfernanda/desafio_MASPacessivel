# Recuperação técnica do golden baseline

A primeira rodada terminou com 105 registros: 90 notas válidas, 9 Faithfulness não avaliáveis por ausência de contexto registrado e 6 erros de timeout. As 69 aprovações exibidas pelo DeepEval são aprovações de métricas; não representam 69 casos. Foram 35 casos.

| Métrica | Aprovados / avaliados | Erros | Não avaliáveis |
|---|---:|---:|---:|
| Answer Relevancy | 20/34 | 1 | 0 |
| Faithfulness | 19/23 | 3 | 9 |
| G-Eval | 30/33 | 2 | 0 |

Não apagar nem modificar `resultados/frente_b/golden_baseline.json` e seu JSONL. A recuperação lê e verifica esses arquivos e a configuração original. Repete somente os timeouts: 01 G-Eval; 02 Answer Relevancy e Faithfulness; 05 Faithfulness; 22 G-Eval; 35 Faithfulness. As notas válidas, inclusive abaixo do corte, e os não avaliáveis são copiados sem nova avaliação.

```powershell
.\.venv\Scripts\python.exe recuperar_deepeval.py golden baseline
```

O comando configura o prazo DeepEval de 1.200 segundos por métrica e uma tentativa automática da biblioteca. O prazo HTTP Ollama continua 300 segundos por chamada, como no código original; falhas de transporte têm a mesma política anterior. Modelo, digest, temperatura, contexto de 16.384 tokens, fontes, respostas e thresholds não mudam. Não há chamada à AWS. Um prazo maior não garante que a recuperação termine sem erros.

Resultados derivados: `resultados/frente_b/golden_baseline_recuperacao.jsonl` e, ao concluir, `golden_baseline_recuperacao.json`. A origem, hashes, alvos e prazos são registrados nos metadados. Esse segundo JSON contém todos os registros, com indicação de recuperação técnica; não deve ser apresentado como execução única sem incidentes.

Se houver interrupção antes do encerramento, acrescente `--retomar` ao mesmo comando. Se já houver JSON final, o executor recusa nova execução. Não repetir notas baixas para melhorar aprovação. Se houver novos erros, investigar antes de executar outra tentativa.

O pytest enumera os 35 casos, mas pula os 30 sem timeout. Somente seis métricas de cinco casos são executadas. A taxa de aprovação dessa execução de recuperação não equivale à taxa do golden inteiro.

Após a recuperação, conferir resultados e integrar explicitamente o arquivo derivado à comparação e às verificações de baseline completo. Os consolidadores atuais ainda leem o arquivo original e, corretamente, o recusam enquanto tiver erros; não sobrescrever esse arquivo para contornar a verificação.

Para as rodadas novas, adotar o mesmo prazo operacional e registrá-lo, distinguindo a rodada original com timeout da recuperação. Próxima etapa após corrigir e conferir o golden: red teaming baseline nas duas frentes, análise de falhas, correções e versão final.

Verificação do suporte: 13 testes locais passaram, incluindo preservação da origem, seleção de timeouts e retomada sem duplicação. Esses testes não chamam o juiz e não comprovam a recuperação real, que depende da execução acima.
