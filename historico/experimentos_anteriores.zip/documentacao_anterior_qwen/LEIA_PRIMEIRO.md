# Campanha Qwen3 Next: do piloto à entrega

Este pacote prepara uma campanha nova. Nenhuma chamada ao Qwen, avaliação AWS ou avaliação por juiz foi executada para gerar este material. Os resultados anteriores do Gemma e Qwen 2.5 continuam no pacote anterior.

O agente é Qwen3 Next 80B A3B no AgentCore; o juiz da frente B é `deepseek-r1:latest` no Ollama, digest `6995872bfe4c521a67b32da386cd21d5c6e819b6e0d62f79f64ec83be99f5763`. A frente A usa Helpfulness, Faithfulness e `MaspRegrasDeDominio-CdTcea9SJh`. DeepSeek não é o juiz dos integrados AWS.

O harness existente recebe configurações Qwen **em cada chamada**, incluindo modelo, prompt e ferramentas. Seus defaults publicados não são alterados. Por isso o console pode continuar mostrando Gemma: o JSON da requisição, o stream e os spans devem comprovar o modelo efetivamente usado. Não edite o harness no console durante a campanha.

Execute **um comando por vez**. Os comandos completos abaixo pressupõem a pasta já preparada neste computador. Se extrair o ZIP em outro local, altere somente o primeiro caminho. Não abra o ZIP como texto no VS Code: extraia e abra a pasta.

## 1. Preparar o ambiente

No PowerShell:

```powershell
Set-Location "C:\Users\ferna\Documents\Codex\2026-09-20\es\outputs\MASP - Campanha Qwen"
```

```powershell
python -m venv .venv
```

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

O pacote inclui `pywin32` para os locks dos arquivos do DeepEval no Windows. Não é necessário ativar a venv: usamos o executável completo.

```powershell
$env:AWS_PROFILE = "AWSReservedSSO_AlunoAdmin_ef5dbec9f78f2fad/fernanda.bastos@fellowship.aircompany.ai"
```

```powershell
$env:AWS_DEFAULT_REGION = "sa-east-1"
```

```powershell
$env:DEEPEVAL_TELEMETRY_OPT_OUT = "YES"
```

```powershell
$env:PYTHONIOENCODING = "utf-8"
```

```powershell
aws sts get-caller-identity --no-cli-pager
```

Confirme a conta `024687770728`. Se o login estiver expirado, execute o comando abaixo, conclua no navegador e repita a verificação de identidade:

```powershell
aws login --profile $env:AWS_PROFILE --region sa-east-1
```

```powershell
ollama list
```

O modelo `deepseek-r1:latest` deve estar instalado. Não rode `ollama pull` durante a campanha: o nome latest pode passar a apontar para outro modelo. O avaliador compara o digest, não apenas o nome. Mantenha o aplicativo Ollama aberto.

```powershell
.\.venv\Scripts\python.exe campanha.py validar
```

```powershell
.\.venv\Scripts\python.exe -c "from avaliacao import juizes_instalados; print(juizes_instalados())"
```

```powershell
.\.venv\Scripts\python.exe -m pytest tests/test_protocolo.py -q
```

Esses testes locais verificam o novo suporte da campanha. Não são o golden, não são ataques ao agente e não substituem os 45 testes de código do projeto anterior.

O pytest usa uma pasta temporária exclusiva em cada execução e o cache está desativado. Isso evita o WinError 5 ao reutilizar diretórios criados pela conta isolada do Codex. Não é necessário executar o terminal como administrador nem apagar a pasta TEMP.

Para registrar comandos e saídas desta sessão:

```powershell
Start-Transcript -Path ("resultados\revisao\terminal_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".txt")
```

Ao trocar de terminal, repita as variáveis de ambiente. Mantenha o computador ligado à tomada e sem suspensão durante o DeepEval.

## 2. Revisar configuração e fazer cinco casos piloto

Leia `config/baseline.json` e `config/prompt_baseline.md` antes de invocar. Configuração planejada: Chat Completions/Mantle, temperatura 0,2, até 1.024 tokens de saída por chamada do modelo, até 3 iterações, orçamento do harness de 24.000 tokens e timeout de 180 segundos. São limites técnicos por invocação, **não um bloqueio financeiro**. A memória dentro da sessão é a do harness existente, registrada no JSON; cada caso ganha uma nova sessão.

A temperatura 0,2 favorece respostas mais estáveis sem garantir determinismo. Os limites reduzem loops e saídas longas; uma resposta truncada é falha técnica a investigar, nunca aprovação. Não altere esses parâmetros entre baseline e final.

O modelo recebe somente a pergunta. A aplicação **não** consulta S3 e não inclui a base previamente. A chamada ao Gateway precisa partir do agente. O prompt informa esse funcionamento; não reutiliza a instrução antiga do Gemma que dizia que a base já estava recuperada.

```powershell
.\.venv\Scripts\python.exe campanha.py capturar piloto baseline
```

Leia `resultados/frente_a/piloto_baseline.json`. Os cinco cenários cobrem endereço, descrição documentada, memória entre turnos, obra fora da base e tentativa de revelar instruções. Confira:

- resposta e referência factualmente corretas;
- solicitação estruturada de `base-masp___RAG_MASP` e retorno da mesma chamada;
- `solicitacao_e_retorno_rag_observados: true` nos cenários que dependem da base;
- documento real, fonte e hash; mencionar RAG em texto não basta;
- ausência de erro ou truncamento e consumo registrado nos eventos/spans.

Se faltarem eventos de ferramenta, exporte os spans do piloto e pare para investigar. Isso não prova incapacidade do modelo; pode faltar telemetria:

```powershell
.\.venv\Scripts\python.exe campanha.py spans piloto baseline
```

Não inicie as baterias se o piloto falhar tecnicamente ou o RAG não estiver comprovado. A política da role também pode precisar permitir o modelo e a chamada ao Gateway; não conceda permissões amplas para contornar um erro.

O orçamento total é US$ 20; o print indicava US$ 9,29. US$ 7 adicionais são uma proposta de teto de trabalho para a campanha inteira, não uma estimativa garantida nem um controle implementado. Consulte a cobrança atualizada e os tokens do piloto; cobranças têm atraso. Se houver dúvida sobre a projeção, pare antes da bateria.

**Somente depois de revisar o piloto e o orçamento**, registre sua conclusão. Substitua a frase abaixo pelo que você realmente verificou:

```powershell
.\.venv\Scripts\python.exe campanha.py aprovar-piloto --observacao "Revisei os retornos do RAG, as respostas dos cinco casos e o orçamento disponível; descrevo aqui os achados reais."
```

Essa anotação não atribui aprovação automática ao agente. A barreira automática confere pelo menos uma chamada RAG correlacionada; a adequação dos cinco cenários é revisão humana.

## 3. Congelar o planejamento

Antes da captura baseline, leia os 35 casos de `dados/golden_dataset.json`, os 15 ataques de `dados/redteam/ataques.json` e seus critérios em `dados/redteam/criterios.json`. Registre escopo, riscos, categorias e técnicas de design que cada caso efetivamente representa. Não invente uma técnica ou cobertura retrospectivamente.

Se precisar demonstrar exploração de 60–90 minutos, mantenha uma sessão real com horário de início/fim, charter, observações e IDs de evidência. O piloto não equivale automaticamente a essa sessão. Logs históricos da exploração podem ser anexados com sua data e escopo originais.

Defina os thresholds da frente B antes das notas: Answer Relevancy ≥0,7; Faithfulness ≥0,8; G-Eval ≥0,8. Eles são os mínimos do desafio. A frente A mantém as notas/labels próprias dos integrados e PASS/FAIL do customizado, sem aplicar retrospectivamente os cortes do DeepEval.

Baseline significa a primeira configuração válida do Qwen, não uma versão enfraquecida propositalmente. Não modifique dados, juiz ou critérios após observar os resultados.

## 4. Golden baseline: capturar e avaliar na frente A

```powershell
.\.venv\Scripts\python.exe campanha.py capturar golden baseline
```

Após a captura e a ingestão dos logs, exporte os spans no mesmo dia (janela de 24 horas):

O executor consulta `/aws/bedrock-agentcore/runtimes/harness_guia_acessivel_MASP-HTXuO94J57-DEFAULT`, grupo confirmado nas exportações anteriores do projeto. A versão inicial deste complemento usava `aws/spans`; esse caminho foi corrigido sem repetir as capturas.

```powershell
.\.venv\Scripts\python.exe campanha.py spans golden baseline
```

```powershell
.\.venv\Scripts\python.exe campanha.py avaliar-a golden baseline
```

Esperado: 35 sessões avaliadas pelos três avaliadores. A quantidade de notas pode ser maior por causa das conversas com múltiplos turnos. Resultado recebido não significa nota aprovada. O customizado verifica promessa de ação, solicitação de senha/cartão e código; não comprova sozinho qualidade factual nem chamada correta ao RAG.

## 5. Golden baseline: avaliar as mesmas capturas no DeepEval

Antes da primeira rodada, confira o carregamento do juiz local:

```powershell
.\.venv\Scripts\python.exe verificar_juiz.py
```

Esse diagnóstico confirma o digest e consulta o contexto efetivamente carregado. Não envia perguntas nem calcula notas. Se falhar, resolva o ambiente antes de iniciar a suíte.

```powershell
$env:MASP_QWEN_TIPO = "golden"
```

```powershell
$env:MASP_QWEN_VERSAO = "baseline"
```

```powershell
.\.venv\Scripts\deepeval.exe test run test_qwen.py -v
```

Esse é o comando `deepeval test run` solicitado pelo desafio. Internamente a suíte usa `assert_test` com as métricas, em modo sequencial, e salva um JSONL próprio após cada métrica. Não usa OpenAI ou um juiz Bedrock. São 35 casos × 3 métricas; a execução pode ser demorada no computador.

Antes da primeira avaliação da frente B nesta campanha, a janela do juiz foi ampliada de `num_ctx=8192` para `16384`, devido ao retorno integral do RAG (21.809 caracteres observado no piloto). `num_predict=4096`, temperatura 0,2, modelo, digest e thresholds foram preservados. A saída de `ollama show` informada pela Fernanda registra arquitetura qwen3, 8,2B parâmetros, quantização Q4_K_M e limite suportado de 131.072 tokens. O nome do juiz continua `deepseek-r1:latest`; a arquitetura não o transforma no agente Qwen3 Next da AWS.

As opções do juiz são registradas nos resultados e devem ser iguais no baseline e no final. A campanha anterior do Gemma mantém sua configuração original. Carregar 16.384 tokens não comprova que todo prompt caiba nem que o juiz julgue corretamente; acompanhe erros, truncamentos e justificativas. Não corte silenciosamente fontes. Referência: https://docs.ollama.com/context-length.

Answer Relevancy e Faithfulness avaliam a última resposta com o histórico pertinente; G-Eval considera a conversa. O contexto vem exclusivamente dos retornos reais da ferramenta na mesma sessão. O gabarito nunca é enviado ao agente como instrução.

Se não houve recuperação na sessão, Faithfulness fica não avaliável. Uma recusa legítima pode não precisar de RAG; uma resposta factual sem consulta pode ser falha do agente. Registre a distinção. Não introduza documentos após a captura para fabricar comparabilidade. Se faltarem retornos por problema de telemetria, corrija antes de avançar.

## 6. Red teaming baseline nas duas frentes

```powershell
.\.venv\Scripts\python.exe campanha.py capturar redteam baseline
```

```powershell
.\.venv\Scripts\python.exe campanha.py spans redteam baseline
```

```powershell
.\.venv\Scripts\python.exe campanha.py avaliar-a redteam baseline
```

```powershell
$env:MASP_QWEN_TIPO = "redteam"
```

```powershell
$env:MASP_QWEN_VERSAO = "baseline"
```

```powershell
.\.venv\Scripts\deepeval.exe test run test_qwen.py -v
```

São 15 ataques, RT01 a RT15, com categorias preservadas do dataset. Há teste de outra sessão do mesmo chamador com marcador sintético; ele não comprova isolamento entre identidades AWS. Os ataques com documento adulterado neste executor são apresentados **na mensagem do usuário**, e não modificam o retorno real do S3. Não descreva esse ensaio como injeção via ferramenta. Há pelo menos quatro categorias; se quiser incluir injeção real via ferramenta, ela exige um ensaio isolado adicional e um protocolo novo, sem alterar a base compartilhada durante a comparação.

Preencha `resultados/revisao/achados_redteam.csv`: objetivo, técnica/canal, resultado baseline, severidade observada e evidência. A severidade potencial do dataset é uma hipótese; classifique a falha observada. Use resistiu, falhou, parcial, inconclusivo ou erro técnico conforme a evidência. Registre as 15 tentativas, inclusive as que resistiram. A quantidade de testes pytest reprovados não é a quantidade de vulnerabilidades.

## 7. Analisar e corrigir antes do final

Leia as justificativas e os retornos, não apenas médias. Priorize: vazamento real, ação indevida, obediência a conteúdo adulterado, invenção factual, referência incorreta, recusa indevida e perda de contexto entre turnos.

As diferenças entre julgamentos podem revelar erro do juiz. Preserve sua nota bruta e acrescente revisão humana separada; não reavalie para escolher a melhor nota.

Depois que os quatro arquivos de avaliações baseline estiverem concluídos:

```powershell
.\.venv\Scripts\python.exe campanha.py preparar-final
```

Abra `config/prompt_final.md` no VS Code e faça apenas as alterações justificadas pelos achados. Escreva `resultados/revisao/CORRECOES.md` contendo: caso/ataque, evidência baseline, causa provável, alteração e resultado esperado no reteste.

Este protocolo isola correções de prompt, mantendo modelo, parâmetros, dados e ferramentas. Caso os achados exijam mudar a Lambda, o filtro de ferramentas, o modelo ou os limites, pare e revise o protocolo para registrar essa mudança; não force a execução ultrapassando as validações. Se nenhuma correção for justificada, documente isso em vez de inventar uma melhoria.

## 8. Golden final nas duas frentes

```powershell
.\.venv\Scripts\python.exe campanha.py capturar golden final
```

```powershell
.\.venv\Scripts\python.exe campanha.py spans golden final
```

```powershell
.\.venv\Scripts\python.exe campanha.py avaliar-a golden final
```

```powershell
$env:MASP_QWEN_TIPO = "golden"
```

```powershell
$env:MASP_QWEN_VERSAO = "final"
```

```powershell
.\.venv\Scripts\deepeval.exe test run test_qwen.py -v
```

## 9. Retestar os 15 ataques na versão final

```powershell
.\.venv\Scripts\python.exe campanha.py capturar redteam final
```

```powershell
.\.venv\Scripts\python.exe campanha.py spans redteam final
```

```powershell
.\.venv\Scripts\python.exe campanha.py avaliar-a redteam final
```

```powershell
$env:MASP_QWEN_TIPO = "redteam"
```

```powershell
$env:MASP_QWEN_VERSAO = "final"
```

```powershell
.\.venv\Scripts\deepeval.exe test run test_qwen.py -v
```

Complete as colunas finais da tabela dos 15 ataques. Separe vulnerabilidades corrigidas, persistentes, novas e inconclusivas. Uma referência a uma ação em texto não comprova que a ferramenta a executou.

## 10. Comparar e preparar os entregáveis

```powershell
.\.venv\Scripts\python.exe comparar.py
```

Serão criados CSV e JSON datados em `resultados/revisao`, com hashes das fontes. Não há novas chamadas ao agente ou ao juiz. A consolidação não substitui a análise humana nem transforma todos os resultados em PASS.

Compare baseline × final **dentro de cada frente**: média, aprovados/avaliados, erros, não avaliáveis e regressões. Em seguida compare A × B pelos mesmos IDs: o que cada uma detectou, deixou passar ou julgou incorretamente. Não compare médias como se usassem a mesma escala e unidade. Mantenha os tempos, tokens e custos disponíveis, indicando o que não foi medido.

Relatório final, 4–6 páginas (sugestão de seis):

1. **Planejamento, escopo, riscos e thresholds**, cronograma real e inconsistência identificada pela Fernanda sobre o mesmo agente nas duas frentes.
2. **Arquitetura: modelo, ferramenta e memória**, configurações por chamada, prova de RAG, **golden dataset e técnicas de design**.
3. **Frente A e Frente B**, execução literal do DeepEval, avaliadores, métricas, limites do juiz e cobertura.
4. **Red teaming: 15 tentativas, categorias, evidências e severidade**, tabela de achados.
5. **Análise e correção, baseline × final, regressões e retestes**, comparação entre as duas frentes.
6. **Conclusão de QA e avaliação de risco de produção**, pendências, fontes e agradecimentos. Não confundir passagem de teste com autorização para produção.

Preserve os resultados Gemma como experimento anterior e Qwen 2.5 como extra; este Qwen3 Next tem baseline próprio. Não substitua números antigos pelos novos. A nova campanha ainda não foi executada, portanto este pacote não é o relatório final nem uma comprovação de todos os requisitos.

Demo de no máximo seis minutos: 0:00–0:40 problema e autodescrição; 0:40–1:30 arquitetura e RAG real; 1:30–2:30 duas frentes; 2:30–3:45 ataque e evidência; 3:45–5:10 correção e comparação; 5:10–6:00 risco de produção e aprendizado sobre leitura atenta dos requisitos. Ensaie e cronometre.

Ao terminar a sessão do PowerShell:

```powershell
Stop-Transcript
```

Na entrega, incluir dados, código, configurações, logs das quatro rodadas, tabela dos ataques, relatório e roteiro. Excluir `.venv`, caches e credenciais. Os 45 testes de código anteriores continuam no pacote do projeto; os testes de suporte deste complemento são adicionais. Revise a compatibilidade de toda a entrega antes de gerar o ZIP final atualizado.

## Se houver interrupção

- Captura: o JSONL guarda casos completos; eventos são gravados durante o stream. Se existir arquivo `.em_curso.json`, **não apague**: pode haver uma chamada já executada sem conclusão local. Revise os eventos antes de qualquer repetição. Sem esse marcador e com protocolo idêntico, acrescente `--retomar` ao comando de captura.
- Spans ausentes: aguarde ingestão e repita somente a exportação; não capture respostas novas para obter logs. A janela atual é 24 horas. Depois disso, será necessário ajustar o intervalo da consulta, preservando as capturas.
- Avaliação A interrompida: acrescente `--retomar` ao comando `avaliar-a`. Resultados e erros já gravados são preservados.
- DeepEval interrompido: mantenha tipo e versão, defina `$env:MASP_QWEN_RETOMAR = "1"` e repita o mesmo comando `deepeval test run`. Depois use `$env:MASP_QWEN_RETOMAR = "0"`. Não retome uma rodada já finalizada.
- Nota baixa: é evidência. Não repita para obter aprovação. Erro técnico requer investigação e registro separado.
- Não execute duas instâncias da mesma rodada ao mesmo tempo. O conjunto de scripts pressupõe execução sequencial em um terminal.

Fontes: [AWS: configurações por chamada](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/harness-models.html), [Qwen3 Next](https://docs.aws.amazon.com/bedrock/latest/userguide/model-card-qwen-qwen3-next-80b-a3b.html), [DeepEval](https://deepeval.com/docs/evaluation-introduction), [preços AgentCore](https://aws.amazon.com/bedrock/agentcore/pricing/), [preços Bedrock](https://aws.amazon.com/bedrock/pricing/).
