# Guia das evidências

O golden permanece com35 casos e o red teaming com15, sem seleção de notas favoráveis.

- Capturas: resultados/frente_a/golden_baseline.json, golden_final.json, redteam_baseline.json e redteam_final.json. Incluem perguntas, respostas, IDs e eventos de ferramenta.
- Spans: resultados/frente_a/spans_*.json. Registros AWS das sessões selecionadas, não todos os logs da conta.
- Notas AWS: resultados/frente_a/avaliacao_*.json. Dois integrados e um customizado.
- DeepEval oficial para comparação: resultados/frente_b/golden_baseline_recuperacao.json, golden_final_recuperacao.json, redteam_baseline.json e redteam_final.json. Os JSONL e originais com erros permanecem para auditoria.
- Comparação: resultados/revisao/comparacao_20260925T130832760234Z.json e CSV. Os oito hashes referenciam as fontes exatas.
- Achados: entrega_resumida/RED_TEAMING_15.csv, com objetivo, técnica, baseline/final, severidade e resposta como evidência.
- Correções: resultados/revisao/CORRECOES.md, config/prompt_baseline.md e config/prompt_final.md.
- Relatório anterior e testes de código: historico/. Não confundir o experimento Gemma/Qwen2.5 com a campanha principal Qwen3 Next.

Os14 testes de suporte atuais são adicionais aos45 testes do projeto anterior (15 agente,15 DeepEval,15 integração). Não são contagem de ataques nem casos golden. O zip não inclui ambiente virtual, caches ou credenciais de autenticação.
