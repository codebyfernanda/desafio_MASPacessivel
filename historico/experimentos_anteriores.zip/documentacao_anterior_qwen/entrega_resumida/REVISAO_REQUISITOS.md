# Conferência final dos requisitos

Leia o relatório de seis páginas, especialmente a tabela da página6. Há evidências de execução das duas frentes com o mesmo agente, 35casos,15ataques, baseline/final, dois avaliadores AWS integrados e um customizado, três métricas DeepEval via CLI/pytest e relatório/demo preparados.

Limites que não foram ocultados: Faithfulness tem não avaliáveis; exploração não tem charter/intervalo exato comprovado; o juiz local não foi demonstrado como o mais forte disponível; não há corte global AWS prévio comprovado; a aprovação métrica não exige automaticamente ferramenta correta; ataques com documento adulterado usam o canal do usuário; RT09não testa identidades AWS diferentes; há vazamento de prompt e erro factual persistentes; roteiro não prova apresentação realizada. Não prometer nota100.

Resultados técnicos consolidados sem erros, após recuperações separadas do golden. O baseline original permanece. Nota baixa válida não motivou nova avaliação.
