# MASP Acessível - entrega consolidada em25/09/2026

Comece por entrega_resumida/RELATORIO_FINAL_6_PAGINAS.pdf e DEMO_6_MINUTOS.md. A campanha principal Qwen3 Next terminou; não é necessário executar novamente. Os resultados não autorizam produção sem supervisão.

Estrutura: dados/ (35golden,15ataques e manifesto da base), config/ (baseline/final), src/ (avaliadores), resultados/frente_a e frente_b (capturas e notas), entrega_resumida/ (relatório, achados e demo), historico/ (Gemma, Qwen2.5, documentação e testes anteriores).

Para conferir sem custo: use os JSON/CSV e hashes. Para reproduzir, leia LEIA_PRIMEIRO.md e RECUPERACAO_DEEPEVAL.md; esses arquivos registram o roteiro de desenvolvimento, inclusive instruções anteriores à conclusão. Scripts recusam sobrescrever rodadas encerradas. O ambiente .venv deve ser criado localmente se necessário; não acompanha o ZIP. Capturas e avaliações AWS podem gerar custo, DeepEval usa Ollama local. Configurações armazenadas identificam recursos da conta original, não os recriam automaticamente em outra conta.

As correções são de prompt. O documento não afirma uso de guardrail gerenciado novo nem resolução de todos os ataques. O modelo atual é comprovado por overrides e spans; o console pode exibir defaults anteriores do harness.

O manifesto principal MANIFESTO_FINAL.json refere-se a esta entrega. Manifestos antigos, quando presentes, documentam pacotes anteriores, não todos os arquivos deste pacote final. Histórico mantido integralmente, exceto caches/ambientes virtuais/temporários. Não usar o README histórico como instrução da campanha principal.

Sete logs históricos tiveram o campo aws.auth.account.access_key ocultado somente nesta cópia compartilhável. Veja historico/SANITIZACAO.json para hashes antes/depois; as notas e respostas foram preservadas. Os hashes dos manifestos históricos referem-se aos originais, mantidos na pasta anterior.
